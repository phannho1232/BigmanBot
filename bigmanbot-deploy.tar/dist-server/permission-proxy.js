import { createRequire as __ombCreateRequire } from "node:module";
const require = __ombCreateRequire(import.meta.url);

// server/permission-proxy.ts
import { connect } from "node:net";
import { randomUUID } from "node:crypto";
import { setTimeout as sleep } from "node:timers/promises";

// shared/ask-question.ts
var MAX_QUESTIONS = 6;
var MAX_OPTIONS = 12;
var MAX_QUESTION_TEXT = 8e3;
var MAX_LABEL = 120;
var MAX_DESCRIPTION = 400;
var MAX_CUSTOM_ANSWER = 2e3;
function text(value, limit) {
  if (typeof value !== "string") return void 0;
  const trimmed = value.trim();
  return trimmed ? trimmed.slice(0, limit).trim() : void 0;
}
function isRecord(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
function parseOption(value) {
  if (typeof value === "string") {
    const label2 = text(value, MAX_LABEL);
    return label2 ? { label: label2 } : null;
  }
  if (!isRecord(value)) return null;
  const label = text(value.label, MAX_LABEL);
  if (!label) return null;
  const description = text(value.description, MAX_DESCRIPTION);
  return description ? { label, description } : { label };
}
function parseQuestion(value) {
  if (!isRecord(value)) return null;
  const question = text(value.question, MAX_QUESTION_TEXT);
  if (!question) return null;
  const options = [];
  const seen = /* @__PURE__ */ new Set();
  for (const raw of Array.isArray(value.options) ? value.options : []) {
    const option = parseOption(raw);
    if (!option || seen.has(option.label)) continue;
    seen.add(option.label);
    options.push(option);
    if (options.length === MAX_OPTIONS) break;
  }
  const header = text(value.header, MAX_LABEL);
  return {
    question,
    ...header ? { header } : {},
    ...value.multiSelect === true ? { multiSelect: true } : {},
    options,
    // only meaningful beside options: with none, free text is the only answer
    ...value.custom === false && options.length ? { custom: false } : {}
  };
}
function parseAskQuestions(input) {
  if (!isRecord(input) || !Array.isArray(input.questions)) return null;
  const questions = [];
  for (const raw of input.questions) {
    const question = parseQuestion(raw);
    if (!question) continue;
    questions.push(question);
    if (questions.length === MAX_QUESTIONS) break;
  }
  return questions.length ? questions : null;
}
var ANSWER_PREAMBLE = "The user answered your questions.";
var JSON_ANSWERS_PREFIX = `${ANSWER_PREAMBLE}

Answers (JSON):
`;
var MAX_ANSWER_ECHO = ANSWER_PREAMBLE.length + MAX_QUESTIONS * ("\n\nQ: \nA: ".length + MAX_QUESTION_TEXT + MAX_OPTIONS * (MAX_LABEL + ", ".length) + MAX_CUSTOM_ANSWER);
function questionAnswersByQuestion(message, questions) {
  return questionAnswersById(message, questions.map((question) => ({ id: question.question, question })));
}
function questionAnswersById(message, questions) {
  const answers = /* @__PURE__ */ Object.create(null);
  const idByText = /* @__PURE__ */ new Map();
  const ambiguous = /* @__PURE__ */ new Set();
  for (const { id, question } of questions) {
    if (idByText.has(question.question)) {
      ambiguous.add(question.question);
      continue;
    }
    idByText.set(question.question, id);
  }
  if (message.startsWith(JSON_ANSWERS_PREFIX)) {
    let pairs;
    try {
      pairs = JSON.parse(message.slice(JSON_ANSWERS_PREFIX.length));
    } catch {
      return {};
    }
    if (!Array.isArray(pairs) || !pairs.every((pair) => Array.isArray(pair) && pair.length === 2 && pair.every((value) => typeof value === "string"))) return {};
    for (const [asked, answer] of pairs) {
      const id = idByText.get(asked);
      if (id && !ambiguous.has(asked) && answer.trim()) answers[id] = answer;
    }
    return answers;
  }
  const blocks = message.matchAll(/(?:^|\n\n)Q: ([\s\S]+?)\nA: ([\s\S]*?)(?=\n\nQ: |$)/g);
  let sawBlock = false;
  for (const match of blocks) {
    sawBlock = true;
    const asked = match[1].trim();
    if (ambiguous.has(asked)) continue;
    const id = idByText.get(asked);
    const answer = match[2].trim();
    if (id && answer) answers[id] = answer;
  }
  if (Object.keys(answers).length) return answers;
  if (sawBlock) return {};
  const only = questions.length === 1 ? questions[0] : void 0;
  const flat = message.trim();
  return only && flat ? { [only.id]: flat } : {};
}

// shared/agents-tool-names.ts
var given = (args, key) => args[key] !== void 0 && args[key] !== null;
function record(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}
var AGENTS_ACTION_TOOLS = {
  trigger_info: { members: ["list_triggers", "list_trigger_events"], member: (args) => args.action === "events" ? "list_trigger_events" : "list_triggers" },
  trigger: { members: ["create_trigger", "manage_trigger"], member: (args) => args.action === "create" ? "create_trigger" : "manage_trigger" },
  delete_trigger: { members: ["manage_trigger"], member: () => "manage_trigger" },
  manage_room: { members: ["manage_room", "create_room"], member: (args) => args.action === "create" ? "create_room" : "manage_room" },
  session_search: { members: ["session_search", "session_read"], member: (args) => given(args, "thread_id") || given(args, "message_id") ? "session_read" : "session_search" },
  show_widget: { members: ["show_widget", "update_widget"], member: (args) => given(args, "widget_id") ? "update_widget" : "show_widget" },
  show_html: { members: ["show_html", "update_html"], member: (args) => given(args, "app_id") ? "update_html" : "show_html" },
  x_search: {
    members: ["x_search", "x_user_posts", "x_post", "x_profile"],
    member: (args) => args.action === "user_posts" ? "x_user_posts" : args.action === "post" ? "x_post" : args.action === "profile" ? "x_profile" : "x_search"
  }
};
var as = (name, args) => ({ name, arguments: args });
var required = (args, key) => ({ ...args, [key]: args[key] ?? "" });
var AGENTS_TOOL_ALIASES = {
  list_triggers: { tools: ["trigger_info"], resolve: (args) => as("trigger_info", { ...args, action: "list" }) },
  list_trigger_events: { tools: ["trigger_info"], resolve: (args) => as("trigger_info", { ...args, action: "events" }) },
  create_trigger: { tools: ["trigger"], resolve: (args) => as("trigger", { ...args, action: "create" }) },
  manage_trigger: {
    tools: ["trigger", "delete_trigger"],
    resolve: ({ changes, ...args }) => {
      const fields = record(changes) ? changes : {};
      if (args.action === "delete") {
        const { action: _delete, ...target } = args;
        return as("delete_trigger", { ...fields, ...target });
      }
      return as("trigger", { ...fields, ...args, action: args.action === "create" ? void 0 : args.action });
    }
  },
  create_room: { tools: ["manage_room"], resolve: (args) => as("manage_room", { ...args, action: "create" }) },
  session_read: { tools: ["session_search"], resolve: (args) => as("session_search", required(required(args, "thread_id"), "message_id")) },
  update_widget: { tools: ["show_widget"], resolve: (args) => as("show_widget", required(args, "widget_id")) },
  update_html: { tools: ["show_html"], resolve: (args) => as("show_html", required(args, "app_id")) },
  x_user_posts: { tools: ["x_search"], resolve: (args) => as("x_search", { ...args, action: "user_posts" }) },
  x_post: { tools: ["x_search"], resolve: (args) => as("x_search", { ...args, action: "post" }) },
  x_profile: { tools: ["x_search"], resolve: (args) => as("x_search", { ...args, action: "profile" }) }
};
var aliasOf = (name) => Object.hasOwn(AGENTS_TOOL_ALIASES, name) ? AGENTS_TOOL_ALIASES[name] : void 0;
var actionToolOf = (name) => Object.hasOwn(AGENTS_ACTION_TOOLS, name) ? AGENTS_ACTION_TOOLS[name] : void 0;
function agentsCallMember(tool, args) {
  return actionToolOf(tool)?.member(record(args) ? args : {}) ?? tool;
}
function named(tool, member) {
  return actionToolOf(tool)?.members.includes(tool) ? [member] : [tool, member];
}
function agentsCallIdentities(name, args) {
  const alias = aliasOf(name);
  if (alias) {
    if (args === void 0) return alias.tools.map((tool2) => named(tool2, name));
    const call = alias.resolve(record(args) ? args : {});
    return [named(call.name, agentsCallMember(call.name, call.arguments))];
  }
  const tool = actionToolOf(name);
  if (!tool) return [[name]];
  return args === void 0 ? tool.members.map((member) => named(name, member)) : [named(name, tool.member(record(args) ? args : {}))];
}

// shared/tool-scope.ts
var SERVER_NAME = /^[a-z][a-z0-9_-]{0,31}$/;
var CONTROL_CHARACTER = /[\x00-\x1f\x7f]/;
var MAX_SELECTORS = 256;
var MAX_SELECTOR_LENGTH = 1024;
function validName(name) {
  return typeof name === "string" && name.trim().length > 0 && name.length <= MAX_SELECTOR_LENGTH && !CONTROL_CHARACTER.test(name) && !name.includes("*");
}
function selectorIdentity(selector) {
  if (selector.length > MAX_SELECTOR_LENGTH || CONTROL_CHARACTER.test(selector)) return;
  if (selector.startsWith("native:")) {
    const name = selector.slice(7);
    if (name === "*" || validName(name)) return { kind: "native", name };
  } else if (selector.startsWith("mcp:")) {
    const separator = selector.indexOf(":", 4);
    if (separator < 0) return;
    const server = selector.slice(4, separator);
    const name = selector.slice(separator + 1);
    if (SERVER_NAME.test(server) && (name === "*" || validName(name))) {
      return { kind: "mcp", server, name };
    }
  }
}
function parseToolScope(value) {
  if (value === void 0) return { ok: true, scope: void 0 };
  const invalid = { ok: false, error: "Tool selection must contain only valid allow and deny lists." };
  if (!value || typeof value !== "object" || Array.isArray(value)) return invalid;
  const prototype = Object.getPrototypeOf(value);
  if (prototype !== Object.prototype && prototype !== null) return invalid;
  const scope = {};
  for (const key of Reflect.ownKeys(value)) {
    if (key !== "allow" && key !== "deny") return invalid;
    const descriptor = Object.getOwnPropertyDescriptor(value, key);
    if (!descriptor || !("value" in descriptor)) return invalid;
    const list = descriptor.value;
    if (!Array.isArray(list) || list.length > MAX_SELECTORS) return invalid;
    if (!Array.from(list).every((entry) => typeof entry === "string" && selectorIdentity(entry))) return invalid;
    scope[key] = [...new Set(list)];
  }
  return { ok: true, scope };
}
function matches(selector, tool, names = [tool.name]) {
  const selected = selectorIdentity(selector);
  return selected?.kind === tool.kind && (selected.kind !== "mcp" || tool.kind === "mcp" && selected.server === tool.server) && (selected.name === "*" || names.includes(selected.name));
}
function permitsNamed(scope, tool, names) {
  return (scope?.allow === void 0 || scope.allow.some((selector) => matches(selector, tool, names))) && !scope?.deny?.some((selector) => matches(selector, tool, names));
}
function permits(scope, tool, args) {
  if (!validName(tool.name) || tool.kind === "mcp" && !SERVER_NAME.test(tool.server)) return false;
  const named2 = tool.kind === "mcp" && tool.server === "agents" ? agentsCallIdentities(tool.name, args) : [[tool.name]];
  return named2.some((names) => permitsNamed(scope, tool, names));
}
function allowsTool(scope, tool, args) {
  const parsed = parseToolScope(scope);
  return parsed.ok && permits(parsed.scope, tool, args);
}

// server/reply-habits.ts
var REFUSED_NEXT_STEP = " Tell the person in one line what you did not do, offer the simplest other way (for a file: drag it into the chat or paste its text), and say what you will deliver once you have it.";

// server/permission-proxy.ts
var selection = parseToolScope(process.env.OMB_PERMISSION_TOOL_SCOPE === void 0 ? void 0 : (() => {
  try {
    return JSON.parse(process.env.OMB_PERMISSION_TOOL_SCOPE);
  } catch {
    return null;
  }
})());
if (!selection.ok) throw new Error(selection.error);
var allowQuestion = allowsTool(selection.scope, { kind: "mcp", server: "ogb", name: "ask_user" });
var socketPath = process.argv[2] ?? "";
var UNREACHABLE_NOTE = {
  question: "OpenMausBot could not show this question to the person: its question service did not answer. Do not retry this tool. Ask in your reply instead: end it with the exact question and stop there until they answer.",
  permission: "OpenMausBot could not ask the person to approve this step: its approval service did not answer. Skip this step, and say in your reply what you wanted to do and why, so the person can decide."
};
var unreachable = (kind) => ({ behavior: "deny", message: UNREACHABLE_NOTE[kind], source: "system" });
var waiting = /* @__PURE__ */ new Map();
var live = null;
var opening = null;
function open() {
  return new Promise((resolve) => {
    const conn = connect(socketPath);
    conn.setEncoding("utf8");
    let connected = false;
    let buf = "";
    conn.on("data", (chunk) => {
      buf += chunk;
      let nl;
      while ((nl = buf.indexOf("\n")) !== -1) {
        const line = buf.slice(0, nl);
        buf = buf.slice(nl + 1);
        let msg;
        try {
          msg = JSON.parse(line);
        } catch {
          continue;
        }
        const entry = msg?.t === "answer" ? waiting.get(String(msg.id)) : void 0;
        if (entry?.conn !== conn) continue;
        waiting.delete(String(msg.id));
        entry.resolve(msg);
      }
    });
    conn.once("connect", () => {
      connected = true;
      resolve(conn);
    });
    conn.on("error", () => {
    });
    conn.once("close", () => {
      if (!connected) resolve(null);
      if (live === conn) live = null;
      for (const [id, entry] of waiting) {
        if (entry.conn !== conn) continue;
        waiting.delete(id);
        entry.resolve(unreachable(entry.kind));
      }
    });
  });
}
function brokerConnection() {
  if (live && !live.destroyed) return Promise.resolve(live);
  opening ??= (async () => {
    for (const pause of [0, 200, 800]) {
      if (pause) await sleep(pause);
      const conn = await open();
      if (conn) return live = conn;
    }
    return null;
  })().finally(() => {
    opening = null;
  });
  return opening;
}
void brokerConnection();
var send = (obj) => process.stdout.write(JSON.stringify(obj) + "\n");
async function askBroker(ask, kind) {
  const conn = await brokerConnection();
  if (!conn || conn.destroyed) return unreachable(kind);
  return new Promise((resolve) => {
    waiting.set(ask.id, { conn, kind, resolve });
    conn.write(JSON.stringify(ask) + "\n", (error) => {
      if (!error || waiting.get(ask.id)?.conn !== conn) return;
      waiting.delete(ask.id);
      resolve(unreachable(kind));
    });
  });
}
function multiSelectQuestion(args) {
  if (args.multiSelect !== true) return null;
  const options = Array.isArray(args.choices) ? args.choices : [];
  return parseAskQuestions({ questions: [{ question: args.question, multiSelect: true, options }] });
}
var ASK_USER_QUESTION = "AskUserQuestion";
var asRecord = (value) => typeof value === "object" && value !== null && !Array.isArray(value) ? value : null;
async function answerNativeQuestions(input) {
  const questions = parseAskQuestions(input);
  if (!questions?.length) {
    return JSON.stringify({
      behavior: "deny",
      message: "OpenMausBot: this AskUserQuestion call had no answerable question (each one needs question text), so nobody was shown it. Ask again with a well-formed call, or continue without it."
    });
  }
  const answer = await askBroker({ t: "ask", id: randomUUID(), kind: "question", tool: ASK_USER_QUESTION, input: { questions } }, "question");
  if (answer.behavior === "deny") {
    return JSON.stringify({ behavior: "deny", message: answer.message || "Denied from OpenMausBot" });
  }
  const answers = answer.source === "user" && typeof answer.message === "string" ? questionAnswersByQuestion(answer.message, questions) : {};
  return JSON.stringify({ behavior: "allow", updatedInput: { ...asRecord(input), answers } });
}
var TOOLS = [
  {
    name: "approve",
    description: "Ask the OpenMausBot user whether a tool use is allowed",
    inputSchema: {
      type: "object",
      properties: {
        tool_name: { type: "string" },
        input: { type: "object" },
        tool_use_id: { type: "string" }
      },
      required: ["tool_name", "input"]
    }
  },
  {
    name: "ask_user",
    description: "Ask the human who owns this bot a question and wait for their answer. Use whenever you need a decision, a preference, missing information, or sign-off before doing something consequential \u2014 do not guess on things the owner would want to decide. Returns their answer as text.",
    inputSchema: {
      type: "object",
      properties: {
        question: { type: "string", description: "The question, with enough context to answer at a glance" },
        choices: {
          type: "array",
          items: { type: "string" },
          description: "Optional 2-5 suggested answers, shown as one-tap buttons"
        },
        multiSelect: {
          type: "boolean",
          description: "Set true when the person may pick more than one of the choices. Their picks come back joined with commas."
        }
      },
      required: ["question"]
    }
  }
];
async function handle(msg) {
  if (msg.method === "initialize") {
    return send({
      jsonrpc: "2.0",
      id: msg.id,
      result: {
        protocolVersion: msg.params?.protocolVersion ?? "2024-11-05",
        capabilities: { tools: {} },
        serverInfo: { name: "openmausbot-permissions", version: "1" }
      }
    });
  }
  if (msg.method === "tools/list") return send({ jsonrpc: "2.0", id: msg.id, result: { tools: TOOLS.filter((tool) => tool.name === "approve" || allowQuestion) } });
  if (msg.method === "tools/call") {
    const name = msg.params?.name;
    const args = msg.params?.arguments ?? {};
    const reply = (text3, isError = false) => send({ jsonrpc: "2.0", id: msg.id, result: { content: [{ type: "text", text: text3 }], ...isError ? { isError } : {} } });
    if (name === "ask_user" && !allowQuestion) return reply("OpenMausBot: this question tool is excluded by the bot's tool selection.");
    if (name === "approve" && args.tool_name === ASK_USER_QUESTION) {
      return reply(await answerNativeQuestions(args.input));
    }
    const askId = randomUUID();
    const isQuestion = name === "ask_user";
    const picksSeveral = isQuestion ? multiSelectQuestion(args) : null;
    const suggestions = Array.isArray(args.permission_suggestions) ? args.permission_suggestions : Array.isArray(args.suggestions) ? args.suggestions : null;
    const answer = await askBroker(
      isQuestion ? { t: "ask", id: askId, kind: "question", tool: "ask_user", input: { question: args.question, choices: args.choices, ...picksSeveral ? { questions: picksSeveral } : {} } } : { t: "ask", id: askId, tool: args.tool_name, input: args.input },
      isQuestion ? "question" : "permission"
    );
    let text2 = answer.message || "No answer was given \u2014 use your best judgment.";
    if (picksSeveral && answer.source === "user" && typeof answer.message === "string") {
      text2 = questionAnswersByQuestion(answer.message, picksSeveral)[picksSeveral[0].question] ?? text2;
    }
    if (!isQuestion) {
      if (answer.behavior === "allow") {
        const result = { behavior: "allow", updatedInput: args.input ?? {} };
        if (answer.always && suggestions) result.updatedPermissions = suggestions;
        text2 = JSON.stringify(result);
      } else {
        text2 = JSON.stringify({ behavior: "deny", message: (answer.message || "Denied from OpenMausBot") + (answer.source === "user" ? REFUSED_NEXT_STEP : "") });
      }
    }
    return reply(text2, isQuestion && answer.behavior === "deny");
  }
  if (String(msg.method ?? "").startsWith("notifications/")) return;
  if (msg.id != null) {
    send({ jsonrpc: "2.0", id: msg.id, error: { code: -32601, message: `method not found: ${msg.method}` } });
  }
}
var inBuf = "";
process.stdin.setEncoding("utf8");
process.stdin.on("data", (chunk) => {
  inBuf += chunk;
  let nl;
  while ((nl = inBuf.indexOf("\n")) !== -1) {
    const line = inBuf.slice(0, nl);
    inBuf = inBuf.slice(nl + 1);
    if (!line.trim()) continue;
    try {
      void handle(JSON.parse(line));
    } catch {
    }
  }
});
process.stdin.on("end", () => process.exit(0));
