// The one Vega config every chart is drawn with (the Data panel, the server's
// SVG/PNG, the headless render check): Vega-Lite's `config`, or Vega's runtime
// config. Light and dark only. Skin accents are not used for marks, so a series
// keeps its colour between the panel and a PNG in an email.
/** The app's `--font-sans` stack. Node renders through resvg, which walks
 * the list against the system fonts it finds, so the stack ends in a
 * generic family. */
export const VEGA_FONT = '"Inter", -apple-system, BlinkMacSystemFont, "SF Pro Text", "Segoe UI", system-ui, sans-serif';
/** Ten categorical colours of middling luminance, each ≥ 3:1 on both #111111
 * and white. Hue order alternates warm and cool so neighbouring series differ. */
export const VEGA_CATEGORY_RANGE = [
    "#3b82f6", // blue
    "#ea580c", // orange
    "#059669", // emerald
    "#c026d3", // fuchsia
    "#a16207", // gold
    "#8b5cf6", // violet
    "#0d9488", // teal
    "#e11d48", // rose
    "#4d7c0f", // olive
    "#6b7280", // grey
];
const INK = {
    dark: { text: "#fcfcfc", muted: "#a3a3a3", hairline: "#333333", surface: "#111111" },
    light: { text: "#1a1a18", muted: "#6b6559", hairline: "#c8bda8", surface: "#fbf8f2" },
};
/** The surface a PNG is laid on when it cannot be transparent (email, Slack). */
export function vegaSurface(theme) {
    return INK[theme].surface;
}
export function vegaConfig(theme) {
    const ink = INK[theme];
    const text = { font: VEGA_FONT, labelFont: VEGA_FONT, titleFont: VEGA_FONT, labelFontSize: 11, titleFontSize: 11, titleFontWeight: 500 };
    return {
        // The panel's card and the phone's view supply the ground; a PNG adds its own.
        background: "transparent",
        font: VEGA_FONT,
        padding: 8,
        view: { stroke: null },
        title: { color: ink.text, subtitleColor: ink.muted, font: VEGA_FONT, fontSize: 13, fontWeight: 600, anchor: "start", offset: 12 },
        axis: {
            ...text,
            labelColor: ink.muted,
            titleColor: ink.muted,
            titlePadding: 8,
            labelPadding: 6,
            domainColor: ink.hairline,
            domainWidth: 1,
            tickColor: ink.hairline,
            tickSize: 4,
            gridColor: ink.hairline,
            gridWidth: 1,
            gridOpacity: 0.6,
        },
        // Hairline grid behind the values only; the category axis keeps its baseline.
        axisX: { grid: false },
        axisY: { grid: true, domain: false, ticks: false },
        legend: {
            ...text,
            labelColor: ink.muted,
            titleColor: ink.muted,
            symbolSize: 60,
            symbolType: "circle",
            labelLimit: 140,
            padding: 0,
            rowPadding: 2,
            columnPadding: 8,
            offset: 12,
        },
        range: {
            category: [...VEGA_CATEGORY_RANGE],
            // High values must pop against the ground: light-to-dark blues on
            // paper, dark-to-bright viridis on a dark surface.
            heatmap: { scheme: theme === "dark" ? "viridis" : "blues" },
            ramp: { scheme: theme === "dark" ? "viridis" : "blues" },
        },
        mark: { color: VEGA_CATEGORY_RANGE[0] },
        line: { strokeWidth: 2, strokeJoin: "round", strokeCap: "round" },
        area: { opacity: 0.75, line: false },
        point: { filled: true, size: 36, opacity: 0.8 },
        circle: { size: 36, opacity: 0.8 },
        // A hairline in the surface colour separates pie slices and heatmap cells.
        arc: { stroke: ink.surface, strokeWidth: 1 },
        rect: { stroke: ink.surface, strokeWidth: 1 },
        text: { color: ink.text, font: VEGA_FONT },
        scale: { bandPaddingInner: 0.25 },
    };
}
