import { narrowsNativeTools, parseToolScope } from "./tool-scope.js";
/** Native contracts and app-supplied MCP gates are separate capabilities. */
export const TOOL_SCOPE_SUPPORT = {
    grok: "native-and-mcp", grokAgent: "native-and-mcp", piAgent: "native-and-mcp",
    "openai-compat": "native-and-mcp", mistral: "native-and-mcp", minimax: "native-and-mcp", cerebras: "native-and-mcp", groq: "native-and-mcp", greenference: "native-and-mcp", meta: "native-and-mcp",
    claudeAgent: "mcp", codex: "mcp", geminiAgent: "mcp", kimiAgent: "mcp", droidAgent: "mcp",
    cursorAgent: "mcp", opencodeGo: "mcp", qwenAgent: "mcp", hermesAgent: "mcp", clineAgent: "mcp", copilotAgent: "mcp", deepseekAgent: "mcp", customAcp: "mcp", antigravityAgent: "mcp", museCode: "mcp",
};
export function assertToolScopeSupported(engine, value) {
    const parsed = parseToolScope(value);
    if (!parsed.ok)
        throw new Error(parsed.error);
    const support = TOOL_SCOPE_SUPPORT[engine];
    if (parsed.scope !== undefined && support !== "native-and-mcp") {
        if (support === undefined) {
            if (parsed.scope.allow !== undefined || parsed.scope.deny?.length)
                throw new Error(`${engine}: tool selection is not supported by this engine. Choose a supported engine.`);
        }
        else if (narrowsNativeTools(parsed.scope)) {
            throw new Error(`${engine}: native tool selection is not supported by this engine. Keep native:* in the selection or choose a supported engine.`);
        }
    }
    return parsed.scope;
}
