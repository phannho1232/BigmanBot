/** The approval levels exposed by the app. Each one is a provider's own
 * permission mode, passed through: OpenMausBot never decides a permission
 * itself (Full access aside, which answers residual prompts because that is
 * what the person granted). The order is the order the selector shows. */
export const APPROVAL_MODES = ["ask", "edits", "auto", "full", "custom"];
/** Only providers with an implemented permission mapping may expose a level.
 * `edits` (auto-accept edits) exists where the engine has such a mode:
 * Claude and Grok `acceptEdits`, Antigravity `auto_edit`, Qwen `auto-edit`,
 * Gemini `auto_edit`. Codex's Ask already runs `workspace-write`, so an edits
 * level would change nothing there. Full access, the default level, runs on
 * every engine: in the engine's own most permissive mode, or, where it has
 * none, with the harness answering the permission requests it leaves (the
 * chat-completions family, ACP agents such as Kimi or Hermes, Pi's computer
 * confirms). */
export function supportsApprovalMode(driverKind, mode) {
    if (mode === "custom")
        return driverKind === "codex";
    if (mode === "edits")
        return ["claudeAgent", "grokAgent", "antigravityAgent", "qwenAgent", "geminiAgent"].includes(driverKind ?? "");
    return true;
}
/** Whether switching engines must first drop this level to Ask. A Custom
 * grant's rules belong to one provider's tool semantics, so it never crosses
 * engines; Full carries silently to any engine; Auto-accept edits stops at an
 * engine without it.
 * Adapted from tahodev's provider-switch guard. */
export function modelSwitchNeedsAsk(mode, fromDriver, toDriver) {
    return !supportsApprovalMode(toDriver, mode) || (mode === "custom" && fromDriver !== toDriver);
}
export function hasNativeAutoReview(driverKind) {
    // Qwen Code's `--approval-mode auto` is an LLM classifier that approves
    // safe actions and blocks risky ones — a reviewer, not a rubber stamp.
    return ["codex", "claudeAgent", "cursorAgent", "grokAgent", "qwenAgent"].includes(driverKind ?? "");
}
const APPROVAL_RANK = { ask: 0, edits: 1, auto: 2, full: 3, custom: 4 };
export function threadApproval(thread, bot) {
    return {
        approvalMode: thread.approvalMode ?? (thread.autoApprove === undefined ? bot.approvalMode : undefined),
        autoApprove: thread.autoApprove ?? bot.autoApprove,
        alwaysAllow: structuredClone(thread.alwaysAllow ?? bot.alwaysAllow),
    };
}
export function approvalModeWidens(from, to) {
    return APPROVAL_RANK[to] > APPROVAL_RANK[from];
}
export function isApprovalMode(value) {
    return typeof value === "string" && APPROVAL_MODES.includes(value);
}
/** The level a bot or conversation runs at until a person picks one: Full
 * access, as in t3code (its DEFAULT_RUNTIME_MODE). Each provider maps it to
 * its own most permissive mode; a real question or a missing credential
 * still reaches a person. */
export const DEFAULT_APPROVAL_MODE = "full";
let defaultApprovalMode = DEFAULT_APPROVAL_MODE;
/** On a shared company workspace Full access comes only from the operator's
 * own policy, so its server makes Ask the default once, at startup. */
export function setDefaultApprovalMode(mode) {
    defaultApprovalMode = mode;
}
/** An unset level runs at the default, the pre-approvalMode Auto bit reads as
 * safe Auto, and an unknown persisted value fails closed to Ask. */
export function approvalModeFor(bot) {
    const grant = bot.approvalGrant;
    const otherThread = grant && typeof grant === "object" && "threadOnly" in grant && grant.threadOnly === true &&
        "threadId" in grant && typeof grant.threadId === "string" && typeof bot.threadId === "string" && grant.threadId !== bot.threadId;
    if (grant && !otherThread)
        return "ask";
    if (isApprovalMode(bot.approvalMode))
        return bot.approvalMode;
    if (bot.autoApprove === true)
        return "auto";
    return bot.approvalMode === undefined ? defaultApprovalMode : "ask";
}
/** A private late-grant recovery may revoke an elevated mode even after a
 * turn began. It can only move to the fail-closed Ask mode, and it also stops
 * the running turn, which a native engine would otherwise finish elevated. */
export function isEmergencyApprovalDowngrade(current, next) {
    return next === "ask" && (current === "full" || current === "custom");
}
