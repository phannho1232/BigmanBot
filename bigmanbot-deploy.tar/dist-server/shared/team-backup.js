import { z } from "zod";
import { mascotFaceColorSchema } from "./bot-avatar.js";
import { CONNECTOR_SLUG_PATTERN, CONNECTOR_TOOL_NAME_PATTERN, MAUS_COLOR_NAMES } from "./wire.js";
import { parseToolScope } from "./tool-scope.js";
export const MAX_TEAM_BACKUP_BYTES = 50 * 1024 * 1024;
export const TEAM_BACKUP_CONTENTS = "Bot profiles, instructions, sections, rooms, playbooks, routines, each bot's memory (MEMORY.md, topic notes and daily logs) and conversation text (all tasks and branches).";
export const TEAM_BACKUP_EXCLUSIONS = "Files, images, custom avatars, account connections, model settings and permissions are not included. Action cards are saved as text. Memory is saved with secrets removed. Imported routines start paused.";
const key = z.string().min(1).max(200);
const name = z.string().trim().min(1).max(200);
const timestamp = z.number().finite().nonnegative();
const color = z.enum(MAUS_COLOR_NAMES);
const message = z.object({
    id: key,
    role: z.enum(["bot", "user"]),
    text: z.string().max(2_000_000),
    at: timestamp,
    parentId: key.nullable(),
    replyToId: key.optional(),
    from: z.object({ botId: key, name, color: z.string().max(40) }).optional(),
    peerPost: z.object({ unattended: z.boolean().optional() }).optional(),
    /** A card the server built from records: it replays to a bot as records, never as the bot's own words. */
    serverCard: z.literal(true).optional(),
});
const task = z.object({
    key,
    title: z.string().max(2_000),
    createdAt: timestamp,
    // Travels only when the first message already named this task, so a
    // restore cannot re-arm one generated title on a row that used it.
    titleFromFirstMessage: z.literal(true).optional(),
    openedBy: z.object({ botId: key, name, at: timestamp, kind: z.enum(["pair", "work"]).optional() }).optional(),
    closedBy: z.object({ botId: key, name, at: timestamp }).optional(),
    /** Only true travels; absence is unpinned. */
    pinned: z.literal(true).optional(),
    /** A conversation's own turn limit, in minutes without progress. Absence keeps the group default. */
    turnTimeoutMinutes: z.number().int().min(1).max(1_440).optional(),
    activeLeafId: key.nullable(),
    messages: z.array(message).max(100_000),
});
const owner = {
    key,
    name,
    section: z.string().max(200).optional(),
    activeTask: key,
    tasks: z.array(task).min(1).max(10_000),
};
const playbook = z.object({
    key, name, summary: z.string().max(24_000),
    triggers: z.array(z.string().max(2_000)).max(100),
    instructions: z.string().max(200_000),
});
const schedule = z.discriminatedUnion("type", [
    z.object({ type: z.literal("once"), at: timestamp }),
    z.object({ type: z.literal("daily"), time: z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/), weekdays: z.array(z.number().int().min(0).max(6)).min(1).max(7) }),
    z.object({ type: z.literal("interval"), everyMinutes: z.number().int().min(5).max(1440), anchorAt: z.number().int().min(0).max(8_640_000_000_000_000) }),
]);
// A bot's memory travels with it, in the same plain markdown it lives in:
// the person's accumulated corrections are part of who the bot is. The
// name gates match the server's (one plain segment ending in .md; a day
// for logs), so an import can never write outside the memory folder.
const memoryText = z.string().max(2_000_000);
const memory = z.object({
    file: memoryText,
    topics: z.array(z.object({ name: z.string().regex(/^[\w][\w .-]{0,199}\.md$/), text: memoryText })).max(1_000),
    logs: z.array(z.object({ name: z.string().regex(/^\d{4}-\d{2}-\d{2}\.md$/), text: memoryText })).max(10_000),
});
/** The private backup is the one portable format grants travel in, so the
 * shape is checked with the same patterns the store validates patches
 * against. Shareable exports never carry grants at all, and an import
 * always lands bots grant-less whatever the file says. */
const connectorTools = z.record(z.string().regex(CONNECTOR_SLUG_PATTERN), z.object({ tools: z.union([z.literal("*"), z.array(z.string().regex(CONNECTOR_TOOL_NAME_PATTERN)).min(1).max(500)]) }));
/** A responder kind from a newer release restores as the room's first
 * member as lead (what a room without one does) instead of refusing the
 * whole backup. Malformed values still fail the schema. */
function knownRoomResponder(value) {
    if (!value || typeof value !== "object" || Array.isArray(value))
        return value;
    const group = value;
    const kind = group.defaultResponder && typeof group.defaultResponder === "object"
        ? group.defaultResponder.kind : undefined;
    if (typeof kind !== "string" || ["member", "everyone", "mentions", "auto"].includes(kind))
        return value;
    const first = Array.isArray(group.memberIds) && typeof group.memberIds[0] === "string" ? group.memberIds[0] : undefined;
    return { ...group, defaultResponder: first ? { kind: "member", botId: first } : { kind: "mentions" } };
}
const backupSchema = z.object({
    format: z.literal("openmaus.backup"),
    version: z.literal(1),
    name,
    exportedAt: timestamp,
    warnings: z.array(z.string().max(2_000)).max(4_000).default([]),
    bots: z.array(z.object({
        ...owner,
        title: z.string().max(2_000),
        description: z.string().max(200_000),
        // Same UTF-8 limit as the profile editor (this schema also runs in the browser).
        soul: z.string().refine((value) => new TextEncoder().encode(value).byteLength <= 24_000, {
            error: "standing instructions must be at most 24000 bytes",
        }).optional(),
        color,
        mascotExpression: z.string().max(80).optional(),
        mascotBody: z.string().max(40).optional(),
        mascotFaceColor: mascotFaceColorSchema.optional(),
        chiefOfStaff: z.boolean(),
        hidden: z.boolean(),
        playbooks: z.array(playbook).max(200),
        connectorTools: connectorTools.optional(),
        toolScope: z.custom((value) => value !== undefined && parseToolScope(value).ok, "Invalid tool selection")
            .transform((value) => { const parsed = parseToolScope(value); return parsed.ok ? parsed.scope : value; }).optional(),
        /** Only false is written and applied: a file can keep a bot off the helper model, never put one on it. */
        helperModel: z.boolean().optional(),
        memory: memory.optional(),
    })).min(1).max(200),
    groups: z.array(z.preprocess(knownRoomResponder, z.object({
        ...owner,
        memberIds: z.array(key).max(200),
        dm: z.boolean(),
        bulletin: z.string().max(200_000),
        defaultResponder: z.discriminatedUnion("kind", [
            z.object({ kind: z.literal("member"), botId: key }),
            z.object({ kind: z.literal("everyone") }),
            z.object({ kind: z.literal("mentions") }),
            z.object({ kind: z.literal("auto"), fallbackBotId: key.optional() }),
        ]),
    }))).max(2_000),
    routines: z.array(z.object({
        name, prompt: z.string().trim().min(1).max(200_000),
        target: z.enum(["bot", "room-goal"]), botId: key, groupId: key.optional(),
        runOn: z.enum(["maus", "cloud"]), schedule,
        durationMinutes: z.number().finite().positive(),
        timeoutMinutes: z.number().int().min(5).max(240).optional(),
        checks: z.array(z.enum(["calendar", "mail", "runs"])).max(3).optional(),
        access: z.literal("read-and-draft").optional(),
        deliver: z.literal("brief").optional(),
    })).max(2_000),
});
/** Validate the whole reference graph before an import can write anything.
 * All keys are file-local; none are ever used as destination record IDs. */
export function parseTeamBackup(input) {
    const parsed = backupSchema.safeParse(input);
    if (!parsed.success) {
        const issue = parsed.error.issues[0];
        throw new Error(`Invalid backup: ${issue.path.join(".") || "file"}: ${issue.message}`);
    }
    const backup = parsed.data;
    const unique = (keys, label) => {
        const set = new Set(keys);
        if (set.size !== keys.length)
            throw new Error(`Invalid backup: duplicate ${label}`);
        return set;
    };
    const bots = unique(backup.bots.map((bot) => bot.key), "bot key");
    const groups = unique(backup.groups.map((group) => group.key), "room key");
    const chiefs = new Set();
    for (const bot of backup.bots) {
        if (!bot.chiefOfStaff)
            continue;
        // Persisted section identity is its exact trimmed display label.
        const section = bot.section?.trim() ?? "";
        if (chiefs.has(section) || bot.hidden)
            throw new Error("Invalid backup: a section must have at most one visible Chief of Staff");
        chiefs.add(section);
    }
    for (const group of backup.groups) {
        if (group.memberIds.some((id) => !bots.has(id)))
            throw new Error("Invalid backup: unknown room member");
        unique(group.memberIds, "room member");
        const lead = group.defaultResponder.kind === "member" ? group.defaultResponder.botId
            : group.defaultResponder.kind === "auto" ? group.defaultResponder.fallbackBotId : undefined;
        if (lead !== undefined && !group.memberIds.includes(lead)) {
            throw new Error("Invalid backup: room responder is not a member");
        }
        if (group.dm && (group.memberIds.length !== 2 || group.tasks.length !== 1))
            throw new Error("Invalid backup: invalid direct-message room");
    }
    for (const routine of backup.routines) {
        if (!bots.has(routine.botId))
            throw new Error("Invalid backup: unknown routine bot");
        if (routine.target === "room-goal") {
            if (routine.runOn !== "maus")
                throw new Error("Invalid backup: room goals must run on this computer");
            const group = backup.groups.find((candidate) => candidate.key === routine.groupId);
            if (routine.groupId !== undefined && (!groups.has(routine.groupId) || !group || group.dm || !group.memberIds.includes(routine.botId))) {
                throw new Error("Invalid backup: unknown routine room or coordinator");
            }
        }
    }
    for (const entry of [...backup.bots, ...backup.groups]) {
        const tasks = unique(entry.tasks.map((task) => task.key), "task key");
        if (!tasks.has(entry.activeTask))
            throw new Error("Invalid backup: unknown active task");
        for (const task of entry.tasks) {
            const messages = unique(task.messages.map((message) => message.id), "message key");
            const seen = new Set();
            for (const message of task.messages) {
                // Parents must precede children: rejects cycles and dangling branches.
                if (message.parentId !== null && !seen.has(message.parentId))
                    throw new Error("Invalid backup: invalid conversation branch");
                if (message.replyToId && !messages.has(message.replyToId))
                    throw new Error("Invalid backup: unknown reply");
                seen.add(message.id);
            }
            if (task.activeLeafId !== null && !messages.has(task.activeLeafId))
                throw new Error("Invalid backup: unknown conversation head");
        }
    }
    return backup;
}
