// Exact app-owned browser state that belongs in an encrypted full backup.
// Never include cookies, authentication tokens, connection caches or unknown keys.
export const WORKSPACE_BACKUP_CLIENT_KEYS = [
    "omb-drafts",
    "omb-draft-attachments",
    "omb-draft-send-ids",
    "omb-draft-channel-modes",
    "omb-skin",
    "omb-show-threads",
    "omb-show-run-card",
    "omb-send-key",
    "omb-color-user-bubbles",
    "omb-chat-width",
    "openmausbot.sidebarDensity",
    "openmausbot.sidebarToolsLayout",
    "openmausbot.sidebarCollapsedSections.v1",
    "openmausbot.sidebarSectionOrder.v1",
    "omb-analytics-opt-out",
    "openmausbot.remote-voice.v1",
];
