// Pure pieces of a Live (GPT-Live) call. With client delegation GPT-Live says
// *that* it wants help, never *what*: `session.delegation.created` carries an id
// and a timeline offset, so the request is rebuilt from the input transcript.
/** Collects `session.input_transcript.delta` fragments on the session
 * timeline. Fragments are appended in delivery order, as the API asks. */
export class LiveTranscript {
    input = [];
    /** when the voice itself was speaking, on the same timeline */
    output = [];
    cutoffMs = -1;
    addInput(text, startMs, endMs) {
        if (!text)
            return;
        this.input.push({ text, startMs: Number.isFinite(startMs) ? startMs : 0, endMs: Number.isFinite(endMs) ? endMs : 0 });
        // keep memory bounded on long calls: only the unconsumed tail matters
        if (this.input.length > 2_000)
            this.input = this.input.filter((segment) => segment.startMs > this.cutoffMs);
    }
    /** A stretch of the voice's own speech (a `session.output_transcript.delta`
     * with its timing). Input heard during it may be the voice itself, picked
     * up again by the microphone of a phone on speaker. Deltas without timing
     * are ignored. */
    addOutput(startMs, endMs) {
        if (!Number.isFinite(startMs) || !Number.isFinite(endMs) || endMs < startMs)
            return;
        const last = this.output.at(-1);
        if (last && startMs <= last.endMs)
            last.endMs = Math.max(last.endMs, endMs);
        else
            this.output.push({ startMs, endMs });
        if (this.output.length > 500)
            this.output.splice(0, this.output.length - 500);
    }
    /** The words spoken since the previous request, up to a little past the
     * delegation point (transcription can trail the delegation event, and the
     * person may finish the sentence that triggered it). Consumes them, so the
     * next request starts after this one. */
    takeRequest(offsetMs, graceMs = 1_500) {
        return this.takeRequestParts(offsetMs, graceMs).text;
    }
    /** takeRequest, plus the same words without those heard while the voice
     * spoke (`withoutEcho`), for reading a spoken yes/no. Consumes all of them. */
    takeRequestParts(offsetMs, graceMs = 1_500) {
        const until = offsetMs + graceMs;
        const taken = this.input.filter((segment) => segment.startMs > this.cutoffMs && segment.startMs <= until);
        if (!taken.length)
            return { text: "", withoutEcho: "" };
        this.cutoffMs = Math.max(this.cutoffMs, ...taken.map((segment) => segment.startMs));
        return {
            text: joinFragments(taken.map((segment) => segment.text)),
            withoutEcho: joinFragments(taken.filter((segment) => !this.echoed(segment)).map((segment) => segment.text)),
        };
    }
    /** Everything heard since the last taken request, without consuming it —
     * used to read a spoken yes/no while a permission question is open.
     * `skipEcho` leaves out what was heard while the voice itself spoke. */
    pending(options = {}) {
        return joinFragments(this.input
            .filter((segment) => segment.startMs > this.cutoffMs && !(options.skipEcho && this.echoed(segment)))
            .map((segment) => segment.text));
    }
    echoed(segment) {
        return this.output.some((span) => segment.startMs < span.endMs && segment.endMs > span.startMs);
    }
    /** Mark everything heard so far as handled (e.g. after a spoken decision). */
    consumeAll() {
        for (const segment of this.input)
            this.cutoffMs = Math.max(this.cutoffMs, segment.startMs);
    }
}
/** Transcript deltas are fragments of words, not words: glue them as sent. */
export function joinFragments(fragments) {
    return fragments.join("").replace(/\s+/g, " ").trim();
}
/** GPT-Live caps each append at 500 tokens. A 500 UTF-8 byte budget is
 * conservative even for emoji/CJK, unlike a prose-only character estimate.
 * Byte-level tokenization cannot produce more tokens than input bytes. */
const APPEND_BYTE_LIMIT = 500;
const encoder = new TextEncoder();
const bytes = (text) => encoder.encode(text).length;
/** Standard UTF-8 accounting; stop at a complete code point, not a surrogate. */
function bytePrefix(text, budget) {
    return new TextDecoder().decode(encoder.encode(text).subarray(0, budget), { stream: true });
}
const MAX_SPOKEN_CHUNKS = 3;
export const FULL_ANSWER_IN_CHAT = "The full answer is in the chat.";
/** Group speakable utterances (from /api/tts/prepare) into appends. Long
 * answers are cut at a sentence boundary with a pointer to the chat, because
 * a voice reading four minutes of a report is not a conversation. */
export function commentaryChunks(utterances) {
    const chunks = [];
    let current = "";
    let truncated = false;
    for (const raw of utterances) {
        const utterance = raw.replace(/\s+/g, " ").trim();
        if (!utterance)
            continue;
        const pieces = bytes(utterance) > APPEND_BYTE_LIMIT ? splitLong(utterance) : [utterance];
        for (const piece of pieces) {
            if (current && bytes(current) + 1 + bytes(piece) > APPEND_BYTE_LIMIT) {
                chunks.push(current);
                current = "";
            }
            if (chunks.length >= MAX_SPOKEN_CHUNKS) {
                truncated = true;
                break;
            }
            current = current ? `${current} ${piece}` : piece;
        }
        if (truncated)
            break;
    }
    if (current && chunks.length < MAX_SPOKEN_CHUNKS)
        chunks.push(current);
    else if (current)
        truncated = true;
    if (truncated && chunks.length) {
        const last = chunks[chunks.length - 1];
        chunks[chunks.length - 1] = bytes(last) + 1 + bytes(FULL_ANSWER_IN_CHAT) <= APPEND_BYTE_LIMIT
            ? `${last} ${FULL_ANSWER_IN_CHAT}`
            : `${bytePrefix(last, APPEND_BYTE_LIMIT - bytes(FULL_ANSWER_IN_CHAT) - 1).replace(/\s+\S*$/, "")} ${FULL_ANSWER_IN_CHAT}`;
    }
    return chunks;
}
function splitLong(text) {
    const out = [];
    let rest = text;
    while (bytes(rest) > APPEND_BYTE_LIMIT) {
        const window = bytePrefix(rest, APPEND_BYTE_LIMIT);
        const sentence = Math.max(window.lastIndexOf(". "), window.lastIndexOf("! "), window.lastIndexOf("? "));
        const space = window.lastIndexOf(" ");
        const cut = sentence > window.length / 2 ? sentence + 1 : space > 0 ? space : window.length;
        out.push(rest.slice(0, cut).trim());
        rest = rest.slice(cut).trim();
    }
    if (rest)
        out.push(rest);
    return out;
}
/** Keep appended content inside the per-append limit. */
export function clampAppend(content) {
    const text = content.replace(/\s+/g, " ").trim();
    return bytes(text) <= APPEND_BYTE_LIMIT ? text : `${bytePrefix(text, APPEND_BYTE_LIMIT - bytes("…")).replace(/\s+\S*$/, "")}…`;
}
/** GPT-Live voices from OpenAI's documentation (Managing GPT-Live sessions,
 * "Voice options", and the SDK's BuiltInVoice list), with the regional
 * notes the docs give for the additional ones. */
export const LIVE_VOICE_OPTIONS = [
    { id: "marin", label: "Marin (default)" },
    { id: "cedar", label: "Cedar" },
    { id: "alloy", label: "Alloy" },
    { id: "ash", label: "Ash" },
    { id: "ballad", label: "Ballad" },
    { id: "coral", label: "Coral" },
    { id: "echo", label: "Echo" },
    { id: "sage", label: "Sage" },
    { id: "shimmer", label: "Shimmer" },
    { id: "verse", label: "Verse" },
    { id: "gleam", label: "Gleam — North American, feminine" },
    { id: "meridian", label: "Meridian — North American, masculine" },
    { id: "quartz", label: "Quartz — Australian, feminine" },
    { id: "ripple", label: "Ripple — Australian, masculine" },
    { id: "vesper", label: "Vesper — British, masculine" },
    { id: "willow", label: "Willow — Irish, feminine" },
    { id: "stone", label: "Stone — Irish, masculine" },
    { id: "delta", label: "Delta — Southern U.S., feminine" },
    { id: "cinder", label: "Cinder — Southern U.S., masculine" },
    { id: "beacon", label: "Beacon — Filipino, masculine" },
    { id: "bossa", label: "Bossa — Brazilian Portuguese, feminine" },
    { id: "tempo", label: "Tempo — Brazilian Portuguese, masculine" },
];
/** A call's length as a clock: m:ss under an hour ("0:07", "1:42"),
 * h:mm:ss from an hour on ("1:02:05"). Whole seconds; a value that is not a
 * length reads as 0:00. */
export function formatCallDuration(seconds) {
    const total = Number.isFinite(seconds) && seconds > 0 ? Math.floor(seconds) : 0;
    const hours = Math.floor(total / 3_600);
    const minutes = Math.floor((total % 3_600) / 60);
    const rest = String(total % 60).padStart(2, "0");
    return hours > 0 ? `${hours}:${String(minutes).padStart(2, "0")}:${rest}` : `${minutes}:${rest}`;
}
/** A Live call row's text: what a client that does not know kind "call"
 * shows as a plain line ("Call with Ada · 1:42"). */
export function liveCallRowText(botName, seconds) {
    return `Call with ${botName} · ${formatCallDuration(seconds)}`;
}
