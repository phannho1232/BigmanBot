// Per-bot connection scopes: which connected apps a bot may use, and whether
// only to read. Absent means every connected app, read and write; present, an
// app not listed is off and "read" refuses anything that is not a read. The
// harness enforces it at the connector relay; the app shows the control.
import { KNOWN_READ_SLUGS } from "./outbound.js";
const READ_VERBS = new Set(["GET", "LIST", "FETCH", "SEARCH", "READ", "FIND", "RETRIEVE", "LOOKUP", "DOWNLOAD", "VIEW", "CHECK", "COUNT"]);
const TOOLKIT_SLUG = /^[a-z0-9][a-z0-9_-]{0,63}$/;
/** The toolkit a Composio slug belongs to: the part before the first
 * underscore, lower-cased. A workbench API proxy belongs to no app. */
export function toolkitOf(slug) {
    const cut = slug.indexOf("_");
    return (cut > 0 ? slug.slice(0, cut) : slug).toLowerCase();
}
/** A read verb first means the tool reads. Creating a draft writes to the
 * account even though it sends nothing, so it is a write here. */
export function isReadOnlyAction(slug, toolkit) {
    if (slug === "COMPOSIO_PROXY_EXECUTE")
        return false;
    if (KNOWN_READ_SLUGS.has(slug))
        return true;
    const cut = toolkit ? toolkit.length : slug.indexOf("_");
    const action = cut > 0 ? slug.slice(cut + 1) : "";
    const first = action.toUpperCase().split(/[^A-Z0-9]+/).find(Boolean);
    return first !== undefined && READ_VERBS.has(first);
}
/** The stored shape, or null when the value is not one. */
export function normalizeConnectorScopes(value) {
    if (!value || typeof value !== "object" || Array.isArray(value))
        return null;
    const raw = value.apps;
    if (!raw || typeof raw !== "object" || Array.isArray(raw))
        return null;
    const apps = Object.create(null);
    for (const [key, scope] of Object.entries(raw)) {
        const slug = key.trim().toLowerCase();
        if (!TOOLKIT_SLUG.test(slug))
            return null;
        if (scope !== "read" && scope !== "write")
            return null;
        apps[slug] = scope;
    }
    return { apps };
}
/** May this bot run these calls? The first refusal wins, so a batch that
 * mixes an allowed read with a forbidden write is refused whole rather
 * than half-run. */
export function connectorAccessDecision(scopes, calls, toolkits = []) {
    if (!scopes)
        return { ok: true };
    for (const call of calls) {
        const toolkit = toolkits.filter(candidate => call.slug.startsWith(candidate.toUpperCase() + "_"))
            .sort((a, b) => b.length - a.length)[0] ?? toolkitOf(call.slug);
        const scope = call.slug === "COMPOSIO_PROXY_EXECUTE" || !Object.hasOwn(scopes.apps, toolkit) ? undefined : scopes.apps[toolkit];
        if (!scope)
            return { ok: false, slug: call.slug, toolkit, reason: "app" };
        if (scope === "read" && !isReadOnlyAction(call.slug, toolkit))
            return { ok: false, slug: call.slug, toolkit, reason: "write" };
    }
    return { ok: true };
}
/** A bot whose scopes switch an app on gets that app's tools: every one, unless its tool list already names some. A tool
 * list that leaves out an app its scopes turn on would give that app no tool on any engine. True when `bot` changed. */
export function grantScopedApps(bot) {
    const tools = bot.connectorTools, scopes = bot.connectorScopes;
    if (!scopes || !tools || typeof tools !== "object" || Array.isArray(tools))
        return false;
    const missing = Object.keys(scopes.apps).filter((slug) => !Object.hasOwn(tools, slug));
    if (!missing.length)
        return false;
    bot.connectorTools = { ...tools, ...Object.fromEntries(missing.map((slug) => [slug, { tools: "*" }])) };
    return true;
}
/** One sentence for the bot's prompt, so it does not spend a turn finding
 * out. Empty when the bot is unscoped. */
export function describeConnectorScopes(scopes) {
    if (!scopes)
        return "";
    const entries = Object.entries(scopes.apps);
    if (entries.length === 0)
        return " This bot has been given no connected apps; do not try to use any.";
    const listed = entries
        .map(([slug, scope]) => `${slug} (${scope === "read" ? "read only" : "read and write"})`)
        .join(", ");
    return ` This bot may use only these connected apps: ${listed}. Do not try others, and do not write to a read-only one.`;
}
