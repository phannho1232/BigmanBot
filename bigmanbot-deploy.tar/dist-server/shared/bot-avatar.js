import { z } from "zod";
export const MASCOT_FACE_COLORS = ["white", "black"];
export const mascotFaceColorSchema = z.enum(MASCOT_FACE_COLORS);
export function mascotFaceInk(value) {
    const color = mascotFaceColorSchema.safeParse(value).data;
    return color === "white" ? "#ffffff" : color === "black" ? "#000000" : undefined;
}
/**
 * `mascot` draws the animated mascot body, filled with the bot's colour
 * gradient. `circle`, `rounded`, and `square` crop the bot's own image
 * instead, shown as it is, with no mascot at all.
 */
export const BOT_AVATAR_CROPS = ["mascot", "circle", "rounded", "square"];
export const botAvatarCropSchema = z.enum(BOT_AVATAR_CROPS);
/** CSS radius for a profile crop. Mascot is drawn, not photo-cropped, so it is not clipped. */
export function avatarCropRadius(crop) {
    if (crop === "circle")
        return "50%";
    if (crop === "rounded")
        return "22%";
    return "0";
}
/** 1 shows the picture with object-fit cover. Larger values zoom in. */
export const AVATAR_ZOOM_MIN = 1;
export const AVATAR_ZOOM_MAX = 3;
/** The point of the picture kept in the middle of the crop, from 0 to 1. */
export const AVATAR_FOCUS_CENTER = 0.5;
export function clampAvatarZoom(value) {
    const parsed = typeof value === "number" ? value : Number.NaN;
    if (!Number.isFinite(parsed))
        return AVATAR_ZOOM_MIN;
    const clamped = Math.min(AVATAR_ZOOM_MAX, Math.max(AVATAR_ZOOM_MIN, parsed));
    return Math.round(clamped * 100) / 100;
}
export function clampAvatarFocus(value) {
    const parsed = typeof value === "number" ? value : Number.NaN;
    if (!Number.isFinite(parsed))
        return AVATAR_FOCUS_CENTER;
    const clamped = Math.min(1, Math.max(0, parsed));
    return Math.round(clamped * 1000) / 1000;
}
/**
 * Custom avatars are deliberately limited to this app's attachment server.
 * Besides making persisted profiles portable across desktop/browser clients,
 * this prevents a bot profile from becoming an external tracking pixel or a
 * script-capable SVG.
 */
export const botAvatarUrlSchema = z
    .string()
    .regex(/^\/api\/attachments\/[A-Za-z0-9-]+\.(?:png|jpg|gif|webp)$/, "must be a stored PNG, JPEG, GIF, or WebP attachment");
export function botAvatarUrlFromStoredPath(path) {
    const name = path.replaceAll("\\", "/").split("/").pop();
    if (!name)
        return null;
    const url = `/api/attachments/${name}`;
    return botAvatarUrlSchema.safeParse(url).success ? url : null;
}
export function botAvatarProfile(value) {
    const profile = {
        avatarCrop: botAvatarCropSchema.safeParse(value.avatarCrop).data ?? "mascot",
    };
    const url = botAvatarUrlSchema.safeParse(value.avatarUrl);
    if (url.success)
        profile.avatarUrl = url.data;
    return profile;
}
