// SKILL.md reading for the server skill store, the package format and the
// renderer. Pure text, so the same rules validate a skill wherever it is read.
/** Spec rule: lowercase alphanumerics with single hyphens, 1-64 chars,
 * folder name must equal it. The regex IS the traversal gate — no dots, no
 * slashes, no way to name a skill "..". */
const SKILL_NAME = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;
export const SKILL_NAME_MAX = 64;
export const DESCRIPTION_MAX = 1024;
/** One SKILL.md may be at most this large; the spec recommends <5k tokens. */
export const SKILL_FILE_MAX_BYTES = 256 * 1024;
export function isSkillName(name) {
    return name.length >= 1 && name.length <= SKILL_NAME_MAX && SKILL_NAME.test(name);
}
/** Browsing tags: lowercase slug-ish words, short enough for chip rows. */
const TAG_PATTERN = /^[a-z0-9][a-z0-9-]{0,23}$/;
export const SKILL_TAGS_MAX = 8;
export function parseSkillTags(raw) {
    if (!raw)
        return undefined;
    const tags = [...new Set(raw.split(",").map((tag) => tag.trim().toLowerCase()).filter((tag) => TAG_PATTERN.test(tag)))].slice(0, SKILL_TAGS_MAX);
    return tags.length > 0 ? tags : undefined;
}
/** Unwraps only a matched quote pair, per YAML: "…" unescapes \" \\ \n, '…' folds '' to '. */
function unquoteScalar(raw) {
    const value = raw.trim();
    if (value.length >= 2) {
        const last = value.length - 1;
        if (value[0] === '"' && value[last] === '"') {
            let out = "";
            for (let i = 1; i < last; i += 1) {
                const c = value[i];
                if (c === "\\" && i + 1 < last) {
                    const next = value[i + 1];
                    if (next === '"' || next === "\\" || next === "n") {
                        out += next === "n" ? "\n" : next;
                        i += 1;
                        continue;
                    }
                }
                out += c;
            }
            return out;
        }
        if (value[0] === "'" && value[last] === "'") {
            return value.slice(1, -1).replace(/''/g, "'");
        }
    }
    return value;
}
/** One-line YAML scalar that parseSkillMd reads back unchanged: plain when unambiguous, else double-quoted. */
export function yamlFrontmatterValue(value) {
    const plain = value.length > 0 &&
        value === value.trim() &&
        !/[\n\r]/.test(value) &&
        !value.includes('"') &&
        !/^["'&*!|>%@`]/.test(value) &&
        !/^[-?:](\s|$)/.test(value) &&
        !/^[[\]{}#,]/.test(value) &&
        !value.includes(": ") &&
        !value.endsWith(":") &&
        !value.includes(" #") &&
        !/["']$/.test(value);
    return plain ? value : `"${value.replace(/(["\\\n])/g, (c) => (c === "\n" ? "\\n" : `\\${c}`))}"`;
}
/** Minimal frontmatter reader for the two required keys plus the two we
 * display. Deliberately not a YAML engine: values are single-line strings in
 * every skill the spec's own examples show, and a parser that cannot
 * evaluate anchors or tags cannot be surprised by them. */
export function parseSkillMd(raw) {
    const frontmatter = readSkillFrontmatter(raw);
    if (!frontmatter)
        return { error: "SKILL.md has no YAML frontmatter (--- block) at the top" };
    const { fields } = frontmatter;
    const name = fields.name ?? "";
    const description = fields.description ?? "";
    if (!isSkillName(name)) {
        return { error: `frontmatter name ${JSON.stringify(name)} is not a valid skill name (lowercase, hyphens, max ${SKILL_NAME_MAX})` };
    }
    if (!description || description.length > DESCRIPTION_MAX) {
        return { error: `frontmatter description is required and must be at most ${DESCRIPTION_MAX} characters` };
    }
    return {
        name,
        description,
        license: fields.license || undefined,
        compatibility: fields.compatibility || undefined,
        tags: parseSkillTags(fields.tags),
        body: frontmatter.body,
    };
}
/** The single-line `key: value` fields of a SKILL.md's frontmatter, keys lowercased; null without a frontmatter block. */
export function readSkillFrontmatter(raw) {
    // A byte order mark (Notepad, PowerShell) would hide the opening ---.
    if (raw.charCodeAt(0) === 0xfeff)
        raw = raw.slice(1);
    const match = raw.match(/^---\r?\n([\s\S]*?)\r?\n---\r?\n?([\s\S]*)$/);
    if (!match)
        return null;
    const fields = {};
    for (const line of match[1].split(/\r?\n/)) {
        const kv = line.match(/^([A-Za-z][\w-]*):\s*(.*)$/);
        if (!kv)
            continue;
        fields[kv[1].toLowerCase()] = unquoteScalar(kv[2]);
    }
    return { fields, body: match[2] ?? "" };
}
/** Static red flags before a human review. Presence is a warning shown in
 * the review screen, never a silent rejection — the reviewer decides. These
 * are the three patterns the public registry audits actually caught. */
export function scanSkillText(raw) {
    const warnings = [];
    if (/[A-Za-z0-9+/]{120,}={0,2}/.test(raw)) {
        warnings.push("contains a long base64-looking blob — a common wrapper for hidden instructions or payloads");
    }
    if (/\b(curl|wget)\b[^\n]{0,200}\|\s*(ba|z|da)?sh\b/.test(raw)) {
        warnings.push("pipes a download straight into a shell (curl|sh) — never enable without understanding why");
    }
    // zero-width and bidi-control characters hide text from the reviewer while
    // the model still reads it — the invisible-instruction trick
    if (/[​-‏‪-‮⁠-⁤﻿]/.test(raw)) {
        warnings.push("contains invisible Unicode characters (zero-width or bidi controls) — text you cannot see");
    }
    return warnings;
}
