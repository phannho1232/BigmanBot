import { createHash, timingSafeEqual } from "node:crypto";
import { closeSync, constants, fstatSync, openSync, readSync } from "node:fs";
const MAX_FILE_BYTES = 1_048_576;
const ID = /^[\w-]{1,128}$/;
const fingerprint = (token) => createHash("sha256").update(token).digest("hex");
const sameFingerprint = (left, right) => {
    const a = Buffer.from(left);
    const b = Buffer.from(right);
    return a.length === b.length && timingSafeEqual(a, b);
};
/** Read through the descriptor whose permissions were checked: a pipe must not block, nor a path swap replace the file before the read. */
function registrations(file) {
    let fd;
    try {
        fd = openSync(file, constants.O_RDONLY | (process.platform === "win32" ? 0 : constants.O_NOFOLLOW | constants.O_NONBLOCK));
        const stat = fstatSync(fd);
        if (!stat.isFile() || stat.size > MAX_FILE_BYTES)
            return [];
        if (process.platform !== "win32" && (stat.mode & 0o077) !== 0) {
            console.warn("[comms] ignoring external runtime credentials: use a private file (chmod 600)");
            return [];
        }
        const bytes = Buffer.alloc(stat.size + 1);
        let count = 0;
        for (;;) {
            const read = readSync(fd, bytes, count, bytes.length - count, null);
            if (!read)
                break;
            count += read;
            if (count > stat.size)
                return [];
        }
        const parsed = JSON.parse(bytes.subarray(0, count).toString("utf8"));
        if (!parsed || typeof parsed !== "object" || Array.isArray(parsed))
            return [];
        return Object.entries(parsed).flatMap(([botId, value]) => {
            if (!ID.test(botId) || !value || typeof value !== "object" || Array.isArray(value))
                return [];
            const { token, threadId } = value;
            if (typeof token !== "string" || token.length < 32 || token.length > 4096 || /\s/.test(token))
                return [];
            if (typeof threadId !== "string" || !ID.test(threadId))
                return [];
            return [{ botId, tokenHash: fingerprint(token), threadId }];
        });
    }
    catch {
        return [];
    }
    finally {
        if (fd !== undefined)
            closeSync(fd);
    }
}
function resolveRegistration(file, tokenHash, botForId) {
    const matches = registrations(file).filter(entry => sameFingerprint(entry.tokenHash, tokenHash));
    // A copied secret must not select a different bot based on JSON key order.
    if (matches.length !== 1)
        return null;
    const registration = matches[0];
    const bot = botForId(registration.botId);
    if (!bot || bot.hidden)
        return null;
    // There is no durable "main thread" (bot.threadId is the UI selection), so every grant needs an explicit binding.
    const task = bot.tasks?.find(candidate => candidate.threadId === registration.threadId);
    if (!task || task.archivedAt !== undefined)
        return null;
    return { botId: bot.id, threadId: task.threadId, tokenHash };
}
export function authorizeExternalRuntime(file, header, botForId) {
    if (typeof header !== "string" || !/^Bearer \S{32,4096}$/.test(header))
        return null;
    return resolveRegistration(file, fingerprint(header.slice(7)), botForId);
}
/** Re-check after every wait: the captured identity is not a lease, and rotation, rebinding, deletion and archive apply now. */
export function externalRuntimeIsActive(file, grant, botForId) {
    const current = resolveRegistration(file, grant.tokenHash, botForId);
    return current?.botId === grant.botId && current.threadId === grant.threadId;
}
