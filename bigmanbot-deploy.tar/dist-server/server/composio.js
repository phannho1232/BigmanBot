import { createHash, randomUUID } from "node:crypto";
import { z } from "zod";
import { SPAWNED_PROXIES } from "./proxy-paths.js";
import { managedConnectorUnavailableReason, managedCustomAuthReason } from "../shared/connector-availability.js";
import { DEFAULT_BACKEND_ORIGIN, apiBase, canonicalToolkitSlug, inputError, keepAuthConfigPick, noAuthConfigReason, projectHeaders, refusedAuthConfigReason, responseError, } from "./composio-project.js";
import { MULTI_ACCOUNT_CONFIG, authConfigRefusal, ensureProjectSession, projectApiKey, sessionForToolkit } from "./composio-session.js";
import { authConfigUseLine, noManagedAuthToolkit, withNoManagedAuthNote } from "./connector-auth-config-hint.js";
import { planAccountLink } from "../shared/connector-account-link.js";
import { CONNECTOR_TOOL_NAME_PATTERN } from "../shared/wire.js";
import { CONNECTOR_ALLOWED_TOOLS_ENV, CONNECTOR_ALLOWED_TOOLS_MAX_BYTES, CONNECTOR_SERVICE_SLUGS_ENV, CONNECTOR_SERVICE_SLUGS_MAX_BYTES, serializeConnectorAllowedTools, serializeConnectorServiceSlugs, } from "./connector-advertisement.js";
import { serviceSlugFor, serviceSlugForCandidates } from "./connector-verdict.js";
import { parseMcpResponse, withToolsListFallback } from "./connector-tools-list.js";
import { brokerAccess } from "./composio-broker-access.js";
export { applyManagedBrokerMessage, brokerAccess, setManagedBrokerAccess } from "./composio-broker-access.js";
export { prepareProjectSession, trustedSessionMcpUrl } from "./composio-session.js";
function toolkitBase() {
    return (process.env.OMB_COMPOSIO_TOOLKITS_API ?? `${DEFAULT_BACKEND_ORIGIN}/api/v3`).replace(/\/$/, "");
}
const connectedAccountResponseSchema = z.object({
    id: z.string().optional(),
    alias: z.string().nullable().optional(),
    status: z.string().optional(),
    updated_at: z.string().optional(),
    toolkit: z.object({ slug: z.string().optional() }).optional(),
});
const connectedAccountsPageSchema = z.object({
    items: z.array(connectedAccountResponseSchema),
    next_cursor: z.string().nullable().optional(),
});
const toolkitItemSchema = z.object({
    slug: z.string().optional(),
    is_no_auth: z.boolean().optional(),
    connected_account: z.object({ id: z.string().optional(), status: z.string().optional() }).nullable().optional(),
});
const toolkitPageSchema = z.object({
    items: z.array(toolkitItemSchema).optional(),
    next_cursor: z.string().nullable().optional(),
});
const connectorServiceSchema = z.object({
    connected: z.boolean(),
    pending: z.boolean().optional(),
    status: z.string().optional(),
    accounts: z.array(z.object({ id: z.string(), alias: z.string().optional(), status: z.string() })).optional(),
});
const connectorServicesResponseSchema = z.object({ services: z.record(z.string(), connectorServiceSchema).optional() });
const removalResponseSchema = z.object({ removed: z.number() });
const authUrlResponseSchema = z.object({ url: z.string().optional() });
const linkResponseSchema = z.object({ redirect_url: z.string().optional() });
const MAX_CONNECTED_ACCOUNT_PAGES = 100;
const ACCOUNT_ID = /^[A-Za-z0-9][A-Za-z0-9_-]{0,127}$/;
const printableAliasSchema = z.string().min(1).max(64).refine((value) => {
    for (const character of value) {
        const codePoint = character.codePointAt(0);
        if (codePoint === undefined || codePoint < 32 || codePoint === 127)
            return false;
    }
    return true;
});
/** Separates caches and transports per credential without keeping another plaintext copy of it. */
function backendFingerprint(kind, endpoint, credential) {
    return createHash("sha256")
        .update(kind)
        .update("\0")
        .update(endpoint)
        .update("\0")
        .update(credential)
        .digest("hex");
}
const MAX_TRACKED_TRANSPORT_SESSIONS = 512;
const transportSessionBackends = new Map();
function rememberTransportSession(sessionId, identity) {
    transportSessionBackends.delete(sessionId);
    transportSessionBackends.set(sessionId, identity);
    while (transportSessionBackends.size > MAX_TRACKED_TRANSPORT_SESSIONS) {
        const oldest = transportSessionBackends.keys().next().value;
        if (oldest === undefined)
            break;
        transportSessionBackends.delete(oldest);
    }
}
function canonicalServiceRecord(services) {
    return Object.fromEntries(Object.entries(services).map(([slug, state]) => [canonicalToolkitSlug(slug), state]));
}
function requestedServiceRecord(services, requested) {
    const canonical = canonicalServiceRecord(services);
    return Object.fromEntries(requested.flatMap((slug) => {
        const state = canonical[canonicalToolkitSlug(slug)];
        return state === undefined ? [] : [[slug, state]];
    }));
}
export function connectionMode(cfg) {
    if (projectApiKey(cfg))
        return "self-hosted";
    if (brokerAccess())
        return "managed";
    return "unavailable";
}
export function configured(cfg) {
    return connectionMode(cfg) !== "unavailable";
}
export function connectorAvailability(cfg, storeState = process.env.OMB_CREDENTIAL_STORE) {
    if (configured(cfg))
        return "configured";
    return storeState === "unavailable" ? "unreadable" : "unconfigured";
}
export function connectorSetup(cfg, managedHost = process.env.OMB_DESKTOP_PARENT === "1") {
    if (configured(cfg))
        return "ready";
    return managedHost ? "service-unavailable" : "needs-setup";
}
async function brokerRequest(path, init, broker = brokerAccess()) {
    if (!broker)
        throw new Error("The connected-apps service is unavailable");
    const headers = new Headers(init?.headers);
    headers.set("authorization", `Bearer ${broker.token}`);
    if (init?.body)
        headers.set("content-type", "application/json");
    return fetch(`${broker.url}${path}`, {
        ...init,
        headers,
        signal: init?.signal ?? AbortSignal.timeout(30_000),
    });
}
async function throwBrokerError(res, fallback) {
    const status = res.status >= 400 && res.status < 500 ? res.status : 502;
    throw Object.assign(new Error(await responseError(res, fallback)), { status });
}
function trustedAuthUrl(value, slug) {
    if (!value)
        throw new Error(`Connected-apps service returned no authorization link for ${slug}`);
    const url = new URL(value);
    if (url.protocol !== "https:" || (url.hostname !== "composio.dev" && !url.hostname.endsWith(".composio.dev"))) {
        throw new Error("Connected-apps service returned an untrusted authorization link");
    }
    return url.toString();
}
export function normalizeAccountAlias(value) {
    if (value === undefined || value === null || value === "")
        return undefined;
    const parsed = z.string().safeParse(value);
    if (!parsed.success)
        throw inputError("Account alias must be text");
    const alias = parsed.data.trim();
    if (!printableAliasSchema.safeParse(alias).success) {
        throw inputError("Account alias must be 1-64 printable characters");
    }
    return alias;
}
function validAccountId(value) {
    return Boolean(value && ACCOUNT_ID.test(value));
}
/** Composio's wording when a toolkit needs one of the project's own auth configs. */
const NEEDS_AUTH_CONFIG = /does not manage auth|auth[_ ]?config/i;
export async function mcpIntegration(cfg, context) {
    if (!configured(cfg))
        return null;
    const allowlist = context.connectorTools === undefined
        ? undefined
        : serializeConnectorAllowedTools(context.connectorTools);
    if (allowlist?.oversized) {
        console.warn(`[composio] connector allowlist for bot ${context.botId} exceeds ${CONNECTOR_ALLOWED_TOOLS_MAX_BYTES} bytes;`
            + " tools/list stays unfiltered and grants are enforced per call");
    }
    const serviceSlugs = context.connectorTools === undefined
        ? undefined
        : serializeConnectorServiceSlugs(await connectedServiceSlugs(cfg, context.as));
    if (serviceSlugs?.oversized) {
        console.warn(`[composio] connector service slugs for bot ${context.botId} exceed ${CONNECTOR_SERVICE_SLUGS_MAX_BYTES} bytes;`
            + " tools/list falls back to plain-prefix resolution");
    }
    return {
        command: process.execPath,
        args: [SPAWNED_PROXIES.connectors],
        env: {
            ELECTRON_RUN_AS_NODE: "1",
            // The bridge gets only this boot's loopback token; project and broker credentials never leave the harness.
            OMB_CONNECTOR_UPSTREAM_URL: `${context.harnessUrl}/api/internal/connectors/mcp`,
            OMB_CONNECTOR_UPSTREAM_HEADERS: JSON.stringify({ authorization: `Bearer ${context.commsToken}` }),
            OMB_HARNESS_URL: context.harnessUrl,
            // A name apart from the agents proxy token: Codex flattens all mounted MCP env into one environment.
            OMB_CONNECTOR_TOKEN: context.commsToken,
            OMB_BOT_ID: context.botId,
            OMB_THREAD_ID: context.threadId,
            ...(allowlist?.env ? { [CONNECTOR_ALLOWED_TOOLS_ENV]: allowlist.env } : {}),
            ...(serviceSlugs?.env ? { [CONNECTOR_SERVICE_SLUGS_ENV]: serviceSlugs.env } : {}),
        },
    };
}
export async function relayMcp(cfg, payload, transportSessionId, beforeSend, signal, as) {
    const apiKey = as ? null : projectApiKey(cfg);
    let url;
    let identity;
    const headers = new Headers({
        "content-type": "application/json",
        accept: "application/json, text/event-stream",
    });
    if (apiKey) {
        const session = await ensureProjectSession(cfg);
        url = session.mcp.url;
        headers.set("x-api-key", apiKey);
        identity = backendFingerprint("project-mcp", url, apiKey);
    }
    else {
        const broker = as ?? brokerAccess();
        if (!broker)
            throw new Error("Connected apps are unavailable");
        url = `${broker.url}/v1/mcp`;
        headers.set("authorization", `Bearer ${broker.token}`);
        identity = backendFingerprint("managed-mcp", url, broker.token);
    }
    const knownIdentity = transportSessionId
        ? transportSessionBackends.get(transportSessionId)
        : undefined;
    const forwardedTransportSessionId = transportSessionId
        && knownIdentity === identity
        ? transportSessionId
        : undefined;
    if (forwardedTransportSessionId) {
        headers.set("mcp-session-id", forwardedTransportSessionId);
    }
    // Discovery may await I/O: check turn authority and permissions after it, right before dispatch.
    beforeSend?.();
    const response = await withToolsListFallback(identity, payload, () => fetch(url, {
        method: "POST",
        headers,
        body: JSON.stringify(payload),
        signal: signal ?? AbortSignal.timeout(10 * 60_000),
    }));
    const declared = Number(response.headers.get("content-length") ?? "0");
    if (declared > 20 * 1024 * 1024)
        throw new Error("Connected-app response exceeded 20 MB");
    const raw = new Uint8Array(await response.arrayBuffer());
    if (raw.byteLength > 20 * 1024 * 1024)
        throw new Error("Connected-app response exceeded 20 MB");
    if (forwardedTransportSessionId)
        rememberTransportSession(forwardedTransportSessionId, identity);
    const nextTransportSessionId = response.headers.get("mcp-session-id") ?? undefined;
    if (nextTransportSessionId)
        rememberTransportSession(nextTransportSessionId, identity);
    const contentType = response.headers.get("content-type") ?? "application/json";
    const toolCall = typeof payload === "object" && payload !== null && !Array.isArray(payload) && payload.method === "tools/call";
    const toolkit = toolCall ? noManagedAuthToolkit(new TextDecoder().decode(raw)) : null;
    const bytes = toolkit
        ? await withNoManagedAuthNote(raw, contentType, toolkit, apiKey ? () => sessionForToolkit(cfg, toolkit, { fresh: true }) : null)
        : raw;
    return { status: response.status, bytes, contentType, transportSessionId: nextTransportSessionId };
}
async function listConnectedAccounts(apiKey, userId, slugs) {
    const accounts = [];
    const seenCursors = new Set();
    let cursor;
    for (let page = 0; page < MAX_CONNECTED_ACCOUNT_PAGES; page += 1) {
        const params = new URLSearchParams({
            limit: "50",
            user_ids: userId,
            order_by: "updated_at",
            order_direction: "desc",
        });
        if (slugs.length)
            params.set("toolkit_slugs", slugs.join(","));
        if (cursor)
            params.set("cursor", cursor);
        const response = await fetch(`${apiBase()}/connected_accounts?${params}`, {
            headers: projectHeaders(apiKey),
            signal: AbortSignal.timeout(15_000),
        });
        if (!response.ok)
            throw new Error(await responseError(response, `Composio accounts: HTTP ${response.status}`));
        const body = connectedAccountsPageSchema.parse(await response.json());
        accounts.push(...body.items);
        const next = body.next_cursor || undefined;
        if (!next || seenCursors.has(next))
            return accounts;
        seenCursors.add(next);
        cursor = next;
    }
    throw new Error("Composio account inventory exceeded the pagination safety limit");
}
async function listSessionToolkits(apiKey, sessionId) {
    const toolkits = [];
    const seenCursors = new Set();
    let cursor;
    for (let page = 0; page < MAX_CONNECTED_ACCOUNT_PAGES; page += 1) {
        // Unfiltered, this endpoint pages through the whole marketplace 50 at a time.
        const params = new URLSearchParams({ limit: "50", is_connected: "true" });
        if (cursor)
            params.set("cursor", cursor);
        const response = await fetch(`${apiBase()}/tool_router/session/${encodeURIComponent(sessionId)}/toolkits?${params}`, { headers: projectHeaders(apiKey), signal: AbortSignal.timeout(15_000) });
        if (!response.ok)
            throw new Error(await responseError(response, `Composio toolkits: HTTP ${response.status}`));
        const body = toolkitPageSchema.parse(await response.json());
        toolkits.push(...(body.items ?? []));
        const next = body.next_cursor || undefined;
        if (!next || seenCursors.has(next))
            return toolkits;
        seenCursors.add(next);
        cursor = next;
    }
    throw new Error("Composio toolkit inventory exceeded the pagination safety limit");
}
function summarizeAccounts(accounts, slugs) {
    const requested = new Set(slugs.map(canonicalToolkitSlug));
    const bySlug = new Map();
    for (const account of accounts) {
        const slug = account.toolkit?.slug ? canonicalToolkitSlug(account.toolkit.slug) : "";
        if (!slug || (requested.size && !requested.has(slug)) || !validAccountId(account.id))
            continue;
        const alias = account.alias?.trim() ?? "";
        const summary = {
            id: account.id,
            status: account.status || "UNKNOWN",
            updatedAt: account.updated_at ?? "",
        };
        if (printableAliasSchema.safeParse(alias).success)
            summary.alias = alias;
        const list = bySlug.get(slug) ?? [];
        list.push(summary);
        bySlug.set(slug, list);
    }
    for (const list of bySlug.values())
        list.sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
    return bySlug;
}
function publicAccount({ id, alias, status }) {
    const account = { id, status };
    if (alias)
        account.alias = alias;
    return account;
}
function serviceStateFromAccounts(accounts) {
    const active = accounts.find((account) => /^active$/i.test(account.status));
    const pending = accounts.find((account) => /^(initiated|initializing|pending)$/i.test(account.status));
    const selected = active ?? pending ?? accounts[0];
    return {
        connected: Boolean(active),
        pending: Boolean(pending),
        status: selected?.status ?? "not_connected",
        accounts: accounts.map(publicAccount),
    };
}
function allServiceStates(accountsBySlug, toolkits) {
    const services = new Map([...accountsBySlug].map(([slug, accounts]) => [slug, serviceStateFromAccounts(accounts)]));
    for (const toolkit of toolkits) {
        const slug = toolkit.slug ? canonicalToolkitSlug(toolkit.slug) : "";
        const selected = toolkit.connected_account;
        const selectedId = validAccountId(selected?.id) ? selected.id : undefined;
        if (!slug || (!toolkit.is_no_auth && !selectedId))
            continue;
        const existingAccounts = accountsBySlug.get(slug) ?? [];
        const accounts = [...existingAccounts];
        if (selectedId && !accounts.some((account) => account.id === selectedId)) {
            accounts.push({ id: selectedId, status: selected?.status ?? "ACTIVE" });
        }
        const accountState = serviceStateFromAccounts(accounts);
        const status = toolkit.is_no_auth ? "ACTIVE" : selected?.status ?? accountState.status;
        services.set(slug, {
            connected: toolkit.is_no_auth === true || accountState.connected || /^active$/i.test(status),
            pending: accountState.pending || /^(initiated|initializing|pending)$/i.test(status),
            status,
            accounts: accountState.accounts,
        });
    }
    return Object.fromEntries(services);
}
export async function connectedServicesInventory(cfg, as) {
    const apiKey = as ? null : projectApiKey(cfg);
    if (!apiKey) {
        const response = await brokerRequest("/v1/connectors/connected", undefined, as);
        if (!response.ok)
            await throwBrokerError(response, `Connected apps: HTTP ${response.status}`);
        const body = connectorServicesResponseSchema.parse(await response.json());
        const services = canonicalServiceRecord(body.services ?? {});
        return {
            services: Object.fromEntries(Object.entries(services).map(([slug, state]) => [slug, {
                    connected: state.connected,
                    pending: state.pending ?? false,
                    status: state.status ?? (state.connected ? "ACTIVE" : "not_connected"),
                    accounts: state.accounts ?? [],
                }])),
            complete: true,
        };
    }
    const session = await ensureProjectSession(cfg);
    const userId = session.config?.user_id ?? cfg.composio?.userId;
    if (!userId)
        throw new Error("Composio Session returned no user ID");
    const [toolkits, accountResult] = await Promise.all([
        listSessionToolkits(apiKey, session.session_id),
        // Scoped project keys can grant Session reads without the raw connected-account list.
        listConnectedAccounts(apiKey, userId, []).then((accounts) => ({ accounts, complete: true }))
            .catch(() => ({ accounts: [], complete: false })),
    ]);
    return {
        services: allServiceStates(summarizeAccounts(accountResult.accounts, []), toolkits),
        complete: accountResult.complete,
    };
}
export async function connectedServices(cfg, as) {
    return (await connectedServicesInventory(cfg, as)).services;
}
/** Rejects a connectorTools patch naming an unconnected service or a tool without its service prefix. Checks that need the
 * network fail open, since call-time enforcement decides. Returns the message or null. */
export async function validateConnectorGrants(cfg, grants) {
    const connected = await connectedServices(cfg).catch(() => null);
    const candidates = connected ? Object.keys(connected) : [];
    for (const [slug, grant] of Object.entries(grants)) {
        if (grant.tools === "*")
            continue;
        const misplaced = grant.tools.filter((tool) => (serviceSlugForCandidates(tool, candidates) ?? serviceSlugFor(tool)) !== slug);
        if (misplaced.length) {
            return `connectorTools.${slug}.tools names tools that belong to another service: ${misplaced.join(", ")}`;
        }
    }
    if (!connected)
        return null;
    const unconnected = Object.keys(grants).filter((slug) => !connected[slug]?.connected);
    if (unconnected.length) {
        return `connectorTools names services that are not connected: ${unconnected.join(", ")}`;
    }
    const catalog = await listToolkits(cfg);
    if (catalog.source !== "api" || !catalog.pagination?.complete)
        return null;
    const known = new Set(catalog.cards.map((card) => card.slug.toLowerCase()));
    const unknown = Object.keys(grants).filter((slug) => !known.has(slug));
    if (unknown.length) {
        return `connectorTools names services missing from the connected-apps catalog: ${unknown.join(", ")}`;
    }
    return null;
}
/** The picker offers exactly what a granted bot's bridge would see. */
export async function listConnectorTools(cfg, options = {}) {
    const identity = connectorToolsIdentity(cfg);
    if (!options.force && connectorToolsCache?.identity === identity
        && Date.now() - connectorToolsCache.at < CONNECTOR_TOOLS_CACHE_MS) {
        return connectorToolsCache.services;
    }
    if (connectorToolsRequest?.identity === identity)
        return connectorToolsRequest.services;
    const walk = collectConnectorTools(cfg).then((services) => {
        connectorToolsCache = { at: Date.now(), identity, services };
        return services;
    });
    connectorToolsRequest = { identity, services: walk };
    try {
        return await walk;
    }
    finally {
        if (connectorToolsRequest?.services === walk)
            connectorToolsRequest = null;
    }
}
const CONNECTOR_TOOLS_CACHE_MS = 60_000;
let connectorToolsCache = null;
/** Cache key per backend, so a config switch never serves the previous backend's tools. */
function connectorToolsIdentity(cfg, as) {
    const apiKey = as ? null : projectApiKey(cfg);
    if (apiKey)
        return backendFingerprint("project-tools", apiBase(), apiKey);
    const broker = as ?? brokerAccess();
    return broker ? backendFingerprint("managed-tools", broker.url, broker.token) : "none";
}
let connectorToolsRequest = null;
/** Real backend slugs, so an underscored service (bland_ai) is never captured by a plain-prefix grant (bland); a failed read answers the last good one. */
export async function connectedServiceSlugs(cfg, as) {
    const identity = connectorToolsIdentity(cfg, as);
    if (connectorServiceSlugsCache?.identity === identity
        && Date.now() - connectorServiceSlugsCache.at < CONNECTOR_SERVICE_SLUGS_CACHE_MS) {
        return connectorServiceSlugsCache.slugs;
    }
    if (connectorServiceSlugsRequest?.identity === identity)
        return connectorServiceSlugsRequest.slugs;
    const walk = connectedServices(cfg, as).then((services) => {
        const slugs = Object.keys(services);
        connectorServiceSlugsCache = { at: Date.now(), identity, slugs };
        return slugs;
    }, () => connectorServiceSlugsCache?.identity === identity ? connectorServiceSlugsCache.slugs : []);
    connectorServiceSlugsRequest = { identity, slugs: walk };
    try {
        return await walk;
    }
    finally {
        if (connectorServiceSlugsRequest?.slugs === walk)
            connectorServiceSlugsRequest = null;
    }
}
const CONNECTOR_SERVICE_SLUGS_CACHE_MS = 60_000;
let connectorServiceSlugsCache = null;
let connectorServiceSlugsRequest = null;
const TOOL_DESCRIPTION_MAX = 240;
const TOOLS_LIST_PAGES_MAX = 10;
function connectorToolListing(tool) {
    if (!tool || typeof tool !== "object" || Array.isArray(tool))
        return null;
    const name = tool.name;
    if (typeof name !== "string" || !CONNECTOR_TOOL_NAME_PATTERN.test(name))
        return null;
    if (name.startsWith("COMPOSIO_"))
        return null;
    if (name.endsWith("_MANAGE_CONNECTIONS") || name.endsWith("_WAIT_FOR_CONNECTIONS"))
        return null;
    const description = tool.description;
    const trimmed = typeof description === "string"
        ? description.replace(/\s+/g, " ").trim().slice(0, TOOL_DESCRIPTION_MAX)
        : "";
    return trimmed ? { name, description: trimmed } : { name };
}
async function collectConnectorTools(cfg) {
    const connected = await connectedServices(cfg).catch(() => null);
    const candidates = connected ? Object.keys(connected) : [];
    const initialize = await relayMcp(cfg, {
        jsonrpc: "2.0",
        id: "omb-grants-initialize",
        method: "initialize",
        params: {
            protocolVersion: "2025-03-26",
            capabilities: {},
            clientInfo: { name: "openmausbot-grant-editor", version: "1" },
        },
    });
    if (initialize.status !== 200) {
        throw new Error(await responseErrorFromBytes(initialize.status, initialize.bytes));
    }
    const transportSessionId = initialize.transportSessionId;
    // Streamable-HTTP MCP servers expect the initialized notification before the first request.
    await relayMcp(cfg, {
        jsonrpc: "2.0",
        method: "notifications/initialized",
    }, transportSessionId).catch(() => undefined);
    const grouped = new Map();
    let cursor;
    for (let page = 0; page < TOOLS_LIST_PAGES_MAX; page += 1) {
        const list = await relayMcp(cfg, {
            jsonrpc: "2.0",
            id: "omb-grants-tools",
            method: "tools/list",
            params: cursor ? { cursor } : {},
        }, transportSessionId);
        if (list.status !== 200) {
            throw new Error(await responseErrorFromBytes(list.status, list.bytes));
        }
        const frame = parseMcpResponse(new TextDecoder().decode(list.bytes), "omb-grants-tools");
        const error = frame && typeof frame.error === "object" && frame.error !== null
            ? frame.error.message
            : undefined;
        if (typeof error === "string" && error)
            throw new Error(error);
        const result = frame && typeof frame.result === "object" && frame.result !== null
            ? frame.result
            : undefined;
        if (!result || !Array.isArray(result.tools)) {
            throw new Error("Composio returned a tools/list response without a tools array");
        }
        for (const tool of result.tools) {
            const listing = connectorToolListing(tool);
            if (!listing)
                continue;
            const slug = serviceSlugForCandidates(listing.name, candidates) ?? serviceSlugFor(listing.name);
            if (!slug)
                continue;
            const bucket = grouped.get(slug) ?? [];
            if (!bucket.some((existing) => existing.name === listing.name))
                bucket.push(listing);
            grouped.set(slug, bucket);
        }
        cursor = typeof result.nextCursor === "string" && result.nextCursor ? result.nextCursor : undefined;
        if (!cursor)
            break;
    }
    for (const bucket of grouped.values())
        bucket.sort((a, b) => a.name.localeCompare(b.name));
    return Object.fromEntries([...grouped.entries()].sort(([a], [b]) => a.localeCompare(b)));
}
async function responseErrorFromBytes(status, bytes) {
    try {
        const body = JSON.parse(new TextDecoder().decode(bytes));
        const message = body && typeof body === "object" && !Array.isArray(body)
            ? body.error
            : undefined;
        if (message && typeof message === "object" && !Array.isArray(message)) {
            const text = message.message;
            if (typeof text === "string" && text)
                return text;
        }
        if (typeof message === "string" && message)
            return message;
    }
    catch {
    }
    return `Composio tools/list: HTTP ${status}`;
}
export async function connectionStatus(cfg, slugs) {
    const canonicalSlugs = [...new Set(slugs.map(canonicalToolkitSlug))];
    const apiKey = projectApiKey(cfg);
    if (!apiKey) {
        const response = await brokerRequest(`/v1/connectors?${new URLSearchParams({ services: canonicalSlugs.join(",") })}`);
        if (!response.ok)
            await throwBrokerError(response, `Connected apps: HTTP ${response.status}`);
        const body = connectorServicesResponseSchema.parse(await response.json());
        return requestedServiceRecord(body.services ?? {}, slugs);
    }
    const session = await ensureProjectSession(cfg);
    const params = new URLSearchParams({ limit: "50" });
    if (canonicalSlugs.length)
        params.set("toolkits", canonicalSlugs.join(","));
    const userId = session.config?.user_id ?? cfg.composio?.userId;
    const [res, accounts] = await Promise.all([
        fetch(`${apiBase()}/tool_router/session/${encodeURIComponent(session.session_id)}/toolkits?${params}`, {
            headers: projectHeaders(apiKey),
            signal: AbortSignal.timeout(15_000),
        }),
        // Session toolkits list an account only once it is usable, so read the account lifecycle too (scoped keys may be denied it).
        userId
            ? listConnectedAccounts(apiKey, userId, canonicalSlugs).catch(() => [])
            : Promise.resolve([]),
    ]);
    if (!res.ok)
        throw new Error(await responseError(res, `Composio toolkits: HTTP ${res.status}`));
    const body = toolkitPageSchema.parse(await res.json());
    const bySlug = new Map((body.items ?? []).flatMap((item) => item.slug ? [[canonicalToolkitSlug(item.slug), item]] : []));
    const accountsBySlug = summarizeAccounts(accounts, canonicalSlugs);
    return Object.fromEntries(slugs.map((slug) => {
        const canonicalSlug = canonicalToolkitSlug(slug);
        const item = bySlug.get(canonicalSlug);
        const serviceAccounts = accountsBySlug.get(canonicalSlug) ?? [];
        const selected = item?.connected_account;
        const selectedId = validAccountId(selected?.id) ? selected.id : undefined;
        const withSelected = selectedId && !serviceAccounts.some((account) => account.id === selectedId)
            ? [...serviceAccounts, { id: selectedId, status: selected?.status ?? "ACTIVE" }]
            : serviceAccounts;
        const accountState = serviceStateFromAccounts(withSelected);
        const state = item?.connected_account?.status
            ?? (item?.is_no_auth ? "ACTIVE" : accountState.status);
        return [slug, {
                connected: item?.is_no_auth === true || accountState.connected || /^active$/i.test(state),
                pending: accountState.pending || /^(initiated|initializing|pending)$/i.test(state),
                status: state,
                accounts: accountState.accounts,
            }];
    }));
}
export async function removeService(cfg, slug, as) {
    const toolkit = canonicalToolkitSlug(slug);
    const apiKey = as ? null : projectApiKey(cfg);
    if (!apiKey) {
        const response = await brokerRequest(`/v1/connectors/${encodeURIComponent(toolkit)}`, { method: "DELETE" }, as);
        if (!response.ok)
            await throwBrokerError(response, `Connected apps: HTTP ${response.status}`);
        return removalResponseSchema.parse(await response.json());
    }
    const session = await ensureProjectSession(cfg);
    const params = new URLSearchParams({ limit: "50", toolkits: toolkit });
    const list = await fetch(`${apiBase()}/tool_router/session/${encodeURIComponent(session.session_id)}/toolkits?${params}`, { headers: projectHeaders(apiKey), signal: AbortSignal.timeout(15_000) });
    if (!list.ok)
        throw new Error(await responseError(list, `Composio toolkits: HTTP ${list.status}`));
    const body = toolkitPageSchema.parse(await list.json());
    const id = body.items?.find((item) => item.slug && canonicalToolkitSlug(item.slug) === toolkit)?.connected_account?.id;
    if (!id)
        return { removed: 0 };
    await deleteConnectedAccount(apiKey, id);
    return { removed: 1 };
}
async function deleteConnectedAccount(apiKey, id) {
    const removed = await fetch(`${apiBase()}/connected_accounts/${encodeURIComponent(id)}?revoke_on_delete=true`, { method: "DELETE", headers: projectHeaders(apiKey), signal: AbortSignal.timeout(30_000) });
    if (!removed.ok)
        throw new Error(await responseError(removed, `Composio disconnect: HTTP ${removed.status}`));
}
/** Disconnect exactly one account after proving it belongs to this user/toolkit. */
export async function removeAccount(cfg, slug, accountId) {
    if (!validAccountId(accountId))
        throw inputError("Invalid connected-account ID");
    const toolkit = canonicalToolkitSlug(slug);
    const apiKey = projectApiKey(cfg);
    if (!apiKey) {
        const response = await brokerRequest(`/v1/connectors/${encodeURIComponent(toolkit)}/accounts/${encodeURIComponent(accountId)}`, { method: "DELETE" });
        if (!response.ok)
            await throwBrokerError(response, `Connected apps: HTTP ${response.status}`);
        return removalResponseSchema.parse(await response.json());
    }
    const session = await ensureProjectSession(cfg);
    const userId = session.config?.user_id ?? cfg.composio?.userId;
    if (!userId)
        throw new Error("Composio Session has no user ID");
    const accounts = await listConnectedAccounts(apiKey, userId, [toolkit]);
    const owned = accounts.some((account) => account.id === accountId
        && account.toolkit?.slug !== undefined
        && canonicalToolkitSlug(account.toolkit.slug) === toolkit);
    if (!owned)
        return { removed: 0 };
    await deleteConnectedAccount(apiKey, accountId);
    return { removed: 1 };
}
/** Readies a bot's connection request before its cards show: an auth config the bot named is checked in the person's own
 * project and kept, and each toolkit's own config is named in the Session. Returns which config each toolkit uses. */
export async function prepareConnectionAuthConfigs(cfg, items) {
    const apiKey = projectApiKey(cfg);
    for (const { slug, authConfigId } of items) {
        if (!authConfigId)
            continue;
        const toolkit = canonicalToolkitSlug(slug);
        if (!apiKey)
            throw inputError(managedCustomAuthReason(toolkit), 409);
        await keepAuthConfigPick(apiKey, toolkit, authConfigId);
    }
    if (!apiKey)
        return undefined;
    const lines = [];
    for (const toolkit of new Set(items.map(({ slug }) => canonicalToolkitSlug(slug)))) {
        // A config Composio won't take yet still gets its card: Connect then says why.
        const { choice } = await sessionForToolkit(cfg, toolkit).catch(() => ({ choice: null }));
        if (choice)
            lines.push(authConfigUseLine(toolkit, choice));
    }
    return lines.length ? lines.join(" ") : undefined;
}
export async function authorizeService(cfg, slug, requestedAlias, as) {
    const alias = normalizeAccountAlias(requestedAlias);
    const toolkit = canonicalToolkitSlug(slug);
    const unavailable = managedConnectorUnavailableReason(as ? "managed" : connectionMode(cfg), toolkit);
    if (unavailable)
        throw inputError(unavailable, 409);
    const apiKey = as ? null : projectApiKey(cfg);
    if (!apiKey) {
        const request = { method: "POST" };
        if (alias)
            request.body = JSON.stringify({ alias });
        const response = await brokerRequest(`/v1/connectors/${encodeURIComponent(toolkit)}/authorize`, request, as);
        if (!response.ok && noManagedAuthToolkit(await response.clone().text().catch(() => ""))) {
            throw inputError(managedCustomAuthReason(toolkit), 409);
        }
        if (!response.ok)
            await throwBrokerError(response, `Connected apps: HTTP ${response.status}`);
        const body = authUrlResponseSchema.parse(await response.json());
        return { url: trustedAuthUrl(body.url, toolkit) };
    }
    const { session } = await sessionForToolkit(cfg, toolkit);
    const userId = session.config?.user_id ?? cfg.composio?.userId;
    if (!userId)
        throw new Error("Composio Session has no user ID");
    const accounts = await listConnectedAccounts(apiKey, userId, [toolkit]).catch(() => []);
    const serviceAccounts = accounts.filter((account) => account.toolkit?.slug !== undefined && canonicalToolkitSlug(account.toolkit.slug) === toolkit);
    const plan = planAccountLink(toolkit, serviceAccounts, alias, MULTI_ACCOUNT_CONFIG.max_accounts_per_toolkit, () => `omb-retry-${randomUUID()}`);
    if (!plan.ok)
        throw inputError(plan.error, plan.status);
    for (const id of plan.replace)
        await deleteConnectedAccount(apiKey, id);
    const linkRequest = { toolkit };
    if (plan.alias)
        linkRequest.alias = plan.alias;
    const link = (sessionId) => fetch(`${apiBase()}/tool_router/session/${encodeURIComponent(sessionId)}/link`, {
        method: "POST",
        headers: projectHeaders(apiKey, true),
        body: JSON.stringify(linkRequest),
        signal: AbortSignal.timeout(30_000),
    });
    let res = await link(session.session_id);
    if (!res.ok) {
        const message = await responseError(res, `Composio authorization: HTTP ${res.status}`);
        if (!NEEDS_AUTH_CONFIG.test(message))
            throw new Error(message);
        const fresh = await sessionForToolkit(cfg, toolkit, { fresh: true });
        if (!fresh.choice) {
            if (fresh.readError)
                throw new Error(`Composio auth configs: ${fresh.readError}`);
            throw inputError(noAuthConfigReason(toolkit));
        }
        res = await link(fresh.session.session_id);
        if (!res.ok) {
            const again = await responseError(res, `Composio authorization: HTTP ${res.status}`);
            if (!NEEDS_AUTH_CONFIG.test(again))
                throw new Error(again);
            throw inputError(refusedAuthConfigReason(toolkit, authConfigRefusal(fresh.choice.id) ?? again));
        }
    }
    const body = linkResponseSchema.parse(await res.json());
    return { url: trustedAuthUrl(body.redirect_url, toolkit) };
}
/** Composio lists meta.categories as `{ id, name }` objects (older payloads: plain strings). */
export function toolkitCategories(raw) {
    if (!Array.isArray(raw))
        return undefined;
    const names = raw
        .map((entry) => typeof entry === "string" ? entry : entry && typeof entry === "object" ? entry.name : undefined)
        .filter((name) => typeof name === "string")
        .map((name) => name.trim().slice(0, 40))
        .filter(Boolean);
    const unique = [...new Set(names)].slice(0, 4);
    return unique.length ? unique : undefined;
}
const CURATED = [
    { slug: "googlesheets", label: "Google Sheets", blurb: "Đọc, cập nhật bảng tính và báo cáo dữ liệu", domain: "sheets.google.com", logo: null, categories: ["Productivity"] },
    { slug: "googledocs", label: "Google Docs", blurb: "Đọc và soạn thảo tài liệu, hợp đồng, kịch bản", domain: "docs.google.com", logo: null, categories: ["Productivity"] },
    { slug: "googledrive", label: "Google Drive", blurb: "Lưu trữ, tìm kiếm và quản lý tệp đám mây", domain: "drive.google.com", logo: null, categories: ["Files"] },
    { slug: "gmail", label: "Gmail", blurb: "Đọc, phân loại và gửi email công việc", domain: "gmail.com", logo: null, categories: ["Communication"] },
    { slug: "googlecalendar", label: "Google Calendar", blurb: "Xem lịch biểu, tạo cuộc họp và lời nhắc", domain: "calendar.google.com", logo: null, categories: ["Productivity"] },
    { slug: "canva", label: "Canva", blurb: "Thiết kế hình ảnh, banner và ấn phẩm truyền thông", domain: "canva.com", logo: null, categories: ["Design"] },
    { slug: "youtube", label: "YouTube", blurb: "Quản lý kênh video, mô tả chuẩn SEO và thống kê", domain: "youtube.com", logo: null, categories: ["Social"] },
    { slug: "facebook", label: "Facebook", blurb: "Đăng bài Fanpage, quản lý nội dung và tương tác", domain: "facebook.com", logo: null, categories: ["Social"] },
    { slug: "instagram", label: "Instagram", blurb: "Đăng ảnh, Reels, quản lý bình luận và tin nhắn Instagram", domain: "instagram.com", logo: "https://logos.composio.dev/api/instagram", categories: ["Social"] },
    { slug: "notion", label: "Notion", blurb: "Quản lý trang ghi chú, tài liệu và cơ sở dữ liệu", domain: "notion.so", logo: null, categories: ["Productivity"] },
    { slug: "trello", label: "Trello", blurb: "Quản lý bảng công việc, thẻ nhiệm vụ và tiến độ", domain: "trello.com", logo: null, categories: ["Productivity"] },
    { slug: "figma", label: "Figma", blurb: "Xem thiết kế giao diện, tệp và ghi chú phản hồi", domain: "figma.com", logo: null, categories: ["Design"] },
    { slug: "google_analytics", label: "Google Analytics", blurb: "Phân tích lưu lượng truy cập website và chuyển đổi", domain: "analytics.google.com", logo: null, categories: ["Analytics"] },
    { slug: "google_search_console", label: "Google Search Console", blurb: "Theo dõi thứ hạng từ khóa SEO, lượt nhấp tìm kiếm và lập chỉ mục website", domain: "search.google.com", logo: "https://logos.composio.dev/api/google_search_console", categories: ["Analytics"] },
    { slug: "googlemeet", label: "Google Meet", blurb: "Tạo phòng họp trực tuyến và quản lý lịch họp", domain: "meet.google.com", logo: null, categories: ["Communication"] },
    { slug: "zoom", label: "Zoom", blurb: "Lên lịch phòng họp trực tuyến và hội thảo", domain: "zoom.us", logo: null, categories: ["Communication"] },
    { slug: "outlook", label: "Microsoft Outlook", blurb: "Quản lý email và lịch làm việc Microsoft 365", domain: "outlook.office.com", logo: null, categories: ["Communication"] },
    { slug: "one_drive", label: "Microsoft OneDrive", blurb: "Lưu trữ và đồng bộ tài liệu Microsoft 365", domain: "onedrive.live.com", logo: null, categories: ["Files"] },
    { slug: "microsoft_teams", label: "Microsoft Teams", blurb: "Nhắn tin nội bộ, nhóm làm việc và họp trực tuyến", domain: "teams.microsoft.com", logo: null, categories: ["Communication"] },
    { slug: "excel", label: "Microsoft Excel", blurb: "Đọc, cập nhật bảng tính Excel (.xlsx), công thức và báo cáo tài chính", domain: "office.com", logo: "https://logos.composio.dev/api/excel", categories: ["Productivity"] },
    { slug: "airtable", label: "Airtable", blurb: "Quản lý bảng cơ sở dữ liệu và bản ghi trực quan", domain: "airtable.com", logo: null, categories: ["Productivity"] },
    { slug: "jira", label: "Jira", blurb: "Quản lý dự án, đầu việc và tiến độ sprint", domain: "atlassian.com", logo: null, categories: ["Developer tools"] },
    { slug: "slack", label: "Slack", blurb: "Nhắn tin kênh nội bộ và nhận thông báo nhóm", domain: "slack.com", logo: null, categories: ["Communication"] },
    { slug: "discord", label: "Discord", blurb: "Quản lý tin nhắn và kênh cộng đồng", domain: "discord.com", logo: null, categories: ["Communication"] },
    { slug: "github", label: "GitHub", blurb: "Quản lý mã nguồn, pull request và issue kỹ thuật", domain: "github.com", logo: null, categories: ["Developer tools"] },
    { slug: "zapier", label: "Zapier", blurb: "Tự động hóa kết nối dữ liệu giữa hàng nghìn ứng dụng", domain: "zapier.com", logo: null, categories: ["Automation"] },
    { slug: "dropbox", label: "Dropbox", blurb: "Lưu trữ và chia sẻ tệp, thư mục dung lượng lớn", domain: "dropbox.com", logo: null, categories: ["Files"] },
    { slug: "hubspot", label: "HubSpot", blurb: "Quản lý thông tin khách hàng và lịch sử chăm sóc CRM", domain: "hubspot.com", logo: null, categories: ["Sales and CRM"] },
    { slug: "linkedin", label: "LinkedIn", blurb: "Xây dựng thương hiệu chuyên nghiệp và tuyển dụng B2B", domain: "linkedin.com", logo: null, categories: ["Social"] },
];
let toolkitCache = null;
export async function listToolkits(cfg) {
    const backendKey = projectApiKey(cfg);
    const broker = backendKey ? null : brokerAccess();
    const identity = backendKey
        ? backendFingerprint("project-catalog", toolkitBase(), backendKey)
        : broker
            ? backendFingerprint("managed-catalog", broker.url, broker.token)
            : null;
    if (identity && toolkitCache?.identity === identity && Date.now() - toolkitCache.at < 10 * 60_000) {
        return { cards: toolkitCache.cards, source: "api", pagination: toolkitCache.pagination };
    }
    if (backendKey || broker) {
        try {
            const items = [];
            const seenCursors = new Set();
            let cursor;
            let lastReportedPage;
            let reportedTotalItems;
            let reportedTotalPages;
            let stop = "limit";
            for (let page = 0; page < MAX_CONNECTED_ACCOUNT_PAGES; page += 1) {
                const params = new URLSearchParams({ limit: "500", sort_by: "usage" });
                if (cursor)
                    params.set("cursor", cursor);
                const res = backendKey
                    ? await fetch(`${toolkitBase()}/toolkits?${params}`, {
                        headers: { "x-api-key": backendKey },
                        signal: AbortSignal.timeout(15_000),
                    })
                    : await brokerRequest(cursor ? `/v1/catalog?cursor=${encodeURIComponent(cursor)}` : "/v1/catalog", {
                        signal: AbortSignal.timeout(15_000),
                    });
                if (!res.ok) {
                    stop = "http-error";
                    break;
                }
                const json = await res.json();
                const pageItems = json.items ?? json.data ?? [];
                if (!Array.isArray(pageItems)) {
                    stop = "bad-page";
                    break;
                }
                items.push(...pageItems);
                const pageTotalItems = Number(json.total_items);
                if (Number.isFinite(pageTotalItems) && pageTotalItems > 0)
                    reportedTotalItems = pageTotalItems;
                // A broker that drops the cursor can replay a page while minting fresh cursors, so trust Composio's current_page movement.
                const reportedPage = Number(json.current_page);
                if (Number.isFinite(reportedPage)) {
                    if (lastReportedPage !== undefined && reportedPage <= lastReportedPage) {
                        stop = "page-stuck";
                        break;
                    }
                    lastReportedPage = reportedPage;
                }
                const pageTotalPages = Number(json.total_pages);
                if (Number.isFinite(pageTotalPages) && pageTotalPages > 0)
                    reportedTotalPages = pageTotalPages;
                if (lastReportedPage !== undefined &&
                    Number.isFinite(pageTotalPages) &&
                    pageTotalPages > 0 &&
                    lastReportedPage >= pageTotalPages) {
                    stop = "total-reached";
                    break;
                }
                const next = typeof json.next_cursor === "string" ? json.next_cursor.trim() : "";
                if (!next) {
                    stop = "end";
                    break;
                }
                if (seenCursors.has(next)) {
                    stop = "cursor-repeated";
                    break;
                }
                seenCursors.add(next);
                cursor = next;
            }
            if (items.length) {
                const cards = items.map((t) => ({
                    slug: canonicalToolkitSlug(String(t.slug ?? t.key ?? t.name ?? "")),
                    label: t.name ?? t.slug ?? "",
                    blurb: (t.meta?.description ?? t.description ?? "").slice(0, 90),
                    logo: t.meta?.logo ?? t.logo ?? null,
                    noAuth: t.no_auth === true,
                    domain: null,
                    ...(toolkitCategories(t.meta?.categories) ? { categories: toolkitCategories(t.meta?.categories) } : {}),
                }));
                const uniqueCards = cards.filter((card, index) => card.slug && cards.findIndex((candidate) => candidate.slug === card.slug) === index);
                const shortOfReportedTotal = reportedTotalItems !== undefined && uniqueCards.length < reportedTotalItems;
                const pagingStoppedEarly = lastReportedPage !== undefined
                    && reportedTotalPages !== undefined
                    && lastReportedPage < reportedTotalPages;
                const stalled = shortOfReportedTotal || pagingStoppedEarly;
                const complete = (stop === "end" || stop === "total-reached") && !stalled;
                const pagination = { items: uniqueCards.length, stalled, complete };
                if (reportedTotalItems !== undefined)
                    pagination.totalItems = reportedTotalItems;
                if (pagination.stalled)
                    pagination.reason = stop;
                if (pagination.stalled) {
                    console.warn(`[composio] marketplace catalog paging stopped early (${stop}) after ${uniqueCards.length} toolkits`
                        + (reportedTotalItems !== undefined ? ` of ~${reportedTotalItems}` : "")
                        + "; serving a partial marketplace");
                }
                toolkitCache = { at: Date.now(), cards: uniqueCards, identity: identity, pagination };
                return { cards: uniqueCards, source: "api", pagination };
            }
        }
        catch { }
    }
    return { cards: CURATED, source: "curated" };
}
export async function toolkitCard(cfg, slug) {
    const normalized = canonicalToolkitSlug(slug);
    const { cards } = await listToolkits(cfg);
    return cards.find((card) => card.slug.toLowerCase() === normalized)
        ?? CURATED.find((card) => card.slug === normalized)
        ?? {
            slug: normalized,
            label: normalized.replace(/[-_]+/g, " ").replace(/\b\w/g, (letter) => letter.toUpperCase()),
            blurb: "Connect this app so your bot can continue",
            logo: null,
            domain: null,
        };
}
export const CURATED_SLUGS = CURATED.map((c) => c.slug);
