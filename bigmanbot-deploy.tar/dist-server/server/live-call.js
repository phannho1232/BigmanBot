// The OpenAI key never leaves the harness: the renderer only ever holds the SDP answer and its media connection.
import { CLOUD_HOME_PLACE } from "./system-prompt.js";
export const LIVE_MODEL = "gpt-live-1";
const OPENAI_BASE = "https://api.openai.com";
export const DEFAULT_LIVE_VOICE = "marin";
export const MAX_SDP_BYTES = 64 * 1024;
export const LIVE_NEEDS_KEY = "Live calls use your own OpenAI key. Add it in Settings → API keys.";
/** The client's data channel is untrusted: it may only hang up; every append goes over the sideband. */
export const LIVE_DATA_CHANNEL = {
    allowed_client_events: ["session.close"],
    allowed_server_events: [
        { type: "session.started" },
        { type: "session.input_transcript.delta" },
        { type: "session.output_transcript.delta" },
        { type: "session.closed" },
        { type: "error" },
        { type: "info" },
    ],
};
/** Only a loopback http URL is accepted, read at call time. */
export function liveBaseUrl(env = process.env) {
    const override = env.OMB_OPENAI_LIVE_URL?.trim() ?? "";
    return /^http:\/\/127\.0\.0\.1:\d{1,5}$/.test(override) ? override : OPENAI_BASE;
}
export function liveSessionsUrl(env = process.env) {
    return `${liveBaseUrl(env)}/v1/live/sessions`;
}
export function liveAttachUrl(sessionId, env = process.env) {
    return `${liveBaseUrl(env).replace(/^http/, "ws")}/v1/live/sessions/${encodeURIComponent(sessionId)}/attach`;
}
// The API caps startup history at 128 messages / 8,192 tokens; stay well inside it.
const HISTORY_MESSAGES = 8;
const HISTORY_MESSAGE_CHARS = 600;
const HISTORY_TOTAL_CHARS = 6_000;
const CREATE_TIMEOUT_MS = 20_000;
export function liveHistoryFrom(messages) {
    return messages
        .filter((message) => message.kind === "text" && typeof message.text === "string" && (message.role === "user" || message.role === "bot"))
        .map((message) => ({ role: message.role === "user" ? "user" : "assistant", text: message.text ?? "" }));
}
export class LiveSessionError extends Error {
    status;
    constructor(message, status) {
        super(message);
        this.status = status;
    }
}
export function liveInstructions(bot, { cloudHome = false } = {}) {
    const name = oneLine(bot.name) || "the agent";
    const title = oneLine(bot.title ?? "");
    const description = oneLine(bot.description ?? "").slice(0, 400);
    const where = cloudHome ? `runs on ${CLOUD_HOME_PLACE}` : "runs in OpenMausBot on the user's own computer";
    const changes = cloudHome ? "My Cloud" : "the computer";
    return [
        `You are ${name}${title ? `, ${title}` : ""}, an AI agent that ${where}.${description ? ` ${description}` : ""}`,
        `To the user you are one assistant, ${name}, and you speak in the first person. Your work — looking things up, using your tools, files and memory, researching, deciding, and answering anything that needs facts this conversation does not hold — happens when you delegate. Delegating is how you think and act; it is not someone else.`,
        "Never mention a backend, delegation, a voice layer, or another system or model doing the work, and never say you are only a voice. Say \"I\" about the work.",
        "Never ask the user whether you may look something up or check something. When it needs checking, delegate at once and say briefly that you are checking.",
        "Speak warmly and naturally, at an unhurried pace. Keep replies short: one or two sentences unless the user asks for more. Speak the language the user speaks.",
        "",
        "Backchannel policy: Use light backchannels. Acknowledge naturally without competing with the user.",
        "Interruption policy: Stop speaking when the user interrupts. Listen to what they say.",
        "Delegation policy:",
        "Backend tools:",
        `- ${name}: your own files, tools, memory, settings and this conversation's history. It researches, writes, changes things on ${changes}, and answers questions, including questions about yourself such as which AI model you run on, your settings, your tools and your memory.`,
        "Delegate to the backend when:",
        "- The user asks a question, asks for work, or gives an instruction.",
        "- The user asks something about you that this conversation does not already answer, for example which AI model you run on.",
        "- The user answers a question you asked, including yes or no to a permission request.",
        "- A correction or a new detail changes work already requested.",
        "Do not delegate to the backend when:",
        "- You can answer from this conversation or from a result that is still current.",
        "- The user only greets you, thanks you, or asks you to repeat something you already said.",
        "- The user only asks whether you are still working or stuck.",
        "- You cannot tell what they are asking for without a brief clarification.",
        "Delegate before giving an answer that depends on backend work.",
        "Do not guess the result while waiting. You may say briefly that you are on it, then wait for the update.",
        "While you work you get quiet status notes: how long you have worked, how many steps you took, and your last step. Answer questions about progress from the latest note in one short sentence. Only say you are stuck when the note shows no new step for several minutes.",
        "Never say that an action happened until the result reports it.",
        "When a permission question comes up, ask it clearly and wait for a clear yes or no. Never answer it yourself.",
    ].join("\n");
}
export function liveInitialInput(history) {
    const picked = [];
    let total = 0;
    for (const message of [...history].reverse()) {
        if (picked.length >= HISTORY_MESSAGES)
            break;
        const text = message.text.replace(/\s+/g, " ").trim().slice(0, HISTORY_MESSAGE_CHARS);
        if (!text)
            continue;
        if (total + text.length > HISTORY_TOTAL_CHARS)
            break;
        total += text.length;
        picked.unshift({ role: message.role, text });
    }
    return picked.map((message) => message.role === "user"
        ? { type: "message", role: "user", content: [{ type: "input_text", text: message.text }] }
        : { type: "message", role: "assistant", content: [{ type: "output_text", text: message.text }] });
}
/** OpenAI rejects an unknown voice name with a clear 400. */
export function liveVoice(voice) {
    const name = voice?.trim().toLowerCase() ?? "";
    return /^[a-z]{2,40}$/.test(name) ? name : DEFAULT_LIVE_VOICE;
}
/** Errors carry a status and a message fit for the user: never the key, never OpenAI's raw body. */
export async function createLiveSession(input) {
    const key = input.key.trim();
    if (!key)
        throw new LiveSessionError("Add an OpenAI API key to use Live calls.", 409);
    if (!input.sdp.trim() || Buffer.byteLength(input.sdp) > MAX_SDP_BYTES) {
        throw new LiveSessionError("The call could not start: the connection offer was invalid.", 400);
    }
    const initialInput = liveInitialInput(input.history);
    const body = {
        session: {
            model: LIVE_MODEL,
            instructions: liveInstructions(input.bot, { cloudHome: input.cloudHome }),
            delegation: { type: "client" },
            audio: { output: { voice: liveVoice(input.voice) } },
            client: { data_channel: LIVE_DATA_CHANNEL },
            ...(initialInput.length ? { input: initialInput } : {}),
        },
        transport: { type: "webrtc", sdp: input.sdp },
    };
    let response;
    try {
        response = await (input.fetchImpl ?? fetch)(input.url ?? liveSessionsUrl(), {
            method: "POST",
            headers: { authorization: `Bearer ${key}`, "content-type": "application/json" },
            body: JSON.stringify(body),
            signal: AbortSignal.timeout(input.timeoutMs ?? CREATE_TIMEOUT_MS),
        });
    }
    catch (error) {
        const timedOut = error instanceof Error && (error.name === "TimeoutError" || error.name === "AbortError");
        throw new LiveSessionError(timedOut ? "OpenAI did not answer in time. Try the call again." : "Could not reach OpenAI. Check the internet connection.", 502);
    }
    if (!response.ok) {
        const failure = await response.json().catch(() => null);
        const param = typeof failure?.error?.param === "string" ? failure.error.param : undefined;
        throw new LiveSessionError(liveErrorMessage(response.status, param), response.status === 429 ? 429 : 502);
    }
    const payload = await response.json().catch(() => null);
    const sessionId = payload?.session?.id;
    const sdp = payload?.transport?.sdp;
    if (typeof sessionId !== "string" || typeof sdp !== "string" || !sdp.trim()) {
        throw new LiveSessionError("OpenAI returned an unexpected answer. Try the call again.", 502);
    }
    return { sessionId, sdp };
}
export function liveErrorMessage(status, param) {
    if (status === 400) {
        return param && /voice/i.test(param)
            ? "OpenAI rejected the voice for this call. Choose another voice."
            : `OpenAI rejected the call settings (HTTP 400${param ? `, ${param.replace(/[^\w.]/g, "").slice(0, 60)}` : ""}).`;
    }
    if (status === 401)
        return "OpenAI rejected the API key. Check the key for Live calls.";
    if (status === 403)
        return "This OpenAI project has no access to GPT-Live. Check the project's model access and billing.";
    if (status === 404)
        return "GPT-Live is not available for this OpenAI project.";
    if (status === 429)
        return "OpenAI is limiting Live sessions right now (rate limit or quota). Try again in a moment.";
    if (status >= 500)
        return "OpenAI had a problem starting the call. Try again in a moment.";
    return `OpenAI could not start the call (HTTP ${status}).`;
}
function oneLine(value) {
    return value.replace(/\s+/g, " ").trim();
}
/** Numbers and short codes only: never what anyone said. */
export function liveCallSummaryLine(body) {
    const count = (value) => {
        const n = Number(value);
        return Number.isFinite(n) && n >= 0 ? Math.min(Math.round(n), 1_000_000) : 0;
    };
    const code = (value) => typeof value === "string" ? value.replace(/[^\w.-]/g, "").slice(0, 40) : "";
    const errors = Array.isArray(body.errors) ? body.errors.slice(0, 5).map(code).filter(Boolean) : [];
    return [
        "[live] call ended",
        `bot=${code(body.botId) || "?"}`,
        `voice=${code(body.voice) || DEFAULT_LIVE_VOICE}`,
        `client=${code(body.client) || "?"}`,
        `seconds=${count(body.seconds)}`,
        `delegations=${count(body.delegations)}`,
        `sentToBot=${count(body.sentToBot)}`,
        `answers=${count(body.answers)}`,
        `approvals=${count(body.approvals)}`,
        `notHeard=${count(body.notHeard)}`,
        `replies=${count(body.replies)}`,
        `end=${code(body.end) || "unknown"}`,
        `errors=${errors.length ? errors.join(",") : "none"}`,
    ].join(" ");
}
