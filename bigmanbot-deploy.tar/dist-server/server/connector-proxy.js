// Connection requests become OpenMausBot chat cards: the agent never authors an auth URL and credentials never pass
// through its transcript. stdout is the MCP transport: never log there.
import readline from "node:readline";
import { randomUUID } from "node:crypto";
import { setTimeout as delay } from "node:timers/promises";
import { CONNECTOR_ALLOWED_TOOLS_ENV, CONNECTOR_SERVICE_SLUGS_ENV, filterToolsListFrame, parseConnectorAllowedToolsEnv, parseConnectorServiceSlugsEnv, withAuthConfigParameter, } from "./connector-advertisement.js";
import { APP_TOOL_NAMES_ENV, APP_TOOLS_ENV, appToolAnswer, appToolCall, appToolEntries, parseAppToolsEnv } from "./connector-app-tools.js";
import { ARGUMENT_REFUSAL, argumentRefusalNote, fitArguments, fittedArgumentsNote } from "./connector-arguments.js";
import { annotateFailedCall } from "./connector-scope-hint.js";
import { withSignedOutHint } from "./connector-signed-out-hint.js";
import { AUTH_CONFIG_ID } from "../shared/connector-availability.js";
import { fitToolListResult } from "./mcp-tool-schema.js";
import { toolSchemaProfileFromEnv } from "./tool-schema-profile.js";
import { capToolListResult, toolLimitFromEnv } from "./tool-count-limit.js";
const UPSTREAM = process.env.OMB_CONNECTOR_UPSTREAM_URL ?? "";
const HARNESS = process.env.OMB_HARNESS_URL ?? "http://127.0.0.1:8799";
const BOT_ID = process.env.OMB_BOT_ID ?? "";
const THREAD_ID = process.env.OMB_THREAD_ID ?? "";
const TOKEN = process.env.OMB_CONNECTOR_TOKEN ?? process.env.OMB_COMMS_TOKEN ?? "";
const ALLOWED_TOOLS = parseConnectorAllowedToolsEnv(process.env[CONNECTOR_ALLOWED_TOOLS_ENV]);
const SERVICE_SLUGS = parseConnectorServiceSlugsEnv(process.env[CONNECTOR_SERVICE_SLUGS_ENV]);
const SCHEMA_PROFILE = toolSchemaProfileFromEnv(process.env);
const TOOL_LIMIT = toolLimitFromEnv(process.env);
const APP_TOOLS = parseAppToolsEnv(process.env[APP_TOOLS_ENV]);
const APP_TOOL_NAMES = process.env[APP_TOOL_NAMES_ENV] === "dotted" ? "dotted" : "plain";
const MAX_RESPONSE_BYTES = 20 * 1024 * 1024;
const INITIALIZE_RELAY_TIMEOUT_MS = 1_000;
const RELAY_TIMEOUT_MS = 10 * 60_000;
const TOOLS_LIST_RETRY_MS = 500;
function parsedHeaders() {
    try {
        const value = JSON.parse(process.env.OMB_CONNECTOR_UPSTREAM_HEADERS ?? "{}");
        if (!value || typeof value !== "object" || Array.isArray(value))
            return {};
        return Object.fromEntries(Object.entries(value).filter((entry) => typeof entry[1] === "string"));
    }
    catch {
        return {};
    }
}
const upstreamHeaders = parsedHeaders();
let upstreamSessionId = "";
/** Each listed tool's input schema, as the connector service listed it: what a call's arguments are fitted to. */
const SCHEMAS = new Map();
/** The connected apps this bot may use, named when a refused call might read as "no such tool". */
const USABLE_APPS = ALLOWED_TOOLS ? SERVICE_SLUGS.filter((slug) => Object.hasOwn(ALLOWED_TOOLS, slug)) : SERVICE_SLUGS;
const send = (message) => process.stdout.write(`${JSON.stringify(message)}\n`);
function textResult(id, text, isError = false) {
    return { jsonrpc: "2.0", id, result: { content: [{ type: "text", text }], ...(isError ? { isError: true } : {}) } };
}
function jsonRpcError(id, message) {
    return { jsonrpc: "2.0", id, error: { code: -32000, message } };
}
function initializeResult(id, protocolVersion) {
    return {
        jsonrpc: "2.0",
        id,
        result: {
            protocolVersion: typeof protocolVersion === "string" && protocolVersion ? protocolVersion : "2024-11-05",
            capabilities: { tools: {} },
            serverInfo: { name: "openmausbot-connectors", version: "1" },
        },
    };
}
async function readBounded(response) {
    const declared = Number(response.headers.get("content-length") ?? "0");
    if (declared > MAX_RESPONSE_BYTES)
        throw new Error("connector response exceeded 20 MB");
    if (!response.body)
        return "";
    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let size = 0;
    let text = "";
    for (;;) {
        const { done, value } = await reader.read();
        if (done)
            break;
        size += value.byteLength;
        if (size > MAX_RESPONSE_BYTES) {
            await reader.cancel();
            throw new Error("connector response exceeded 20 MB");
        }
        text += decoder.decode(value, { stream: true });
    }
    return text + decoder.decode();
}
function parseUpstream(text, id) {
    const trimmed = text.trim();
    if (!trimmed)
        return null;
    if (trimmed.startsWith("{"))
        return JSON.parse(trimmed);
    const frames = trimmed
        .split(/\r?\n/)
        .filter((line) => line.startsWith("data:"))
        .map((line) => line.slice(5).trim())
        .filter((line) => line && line !== "[DONE]")
        .flatMap((line) => {
        try {
            return [JSON.parse(line)];
        }
        catch {
            return [];
        }
    });
    return frames.findLast((frame) => frame.id === id) ?? frames.at(-1) ?? null;
}
async function relay(message, timeoutMs = RELAY_TIMEOUT_MS) {
    if (!UPSTREAM)
        throw new Error("connected apps are unavailable");
    const response = await fetch(UPSTREAM, {
        method: "POST",
        headers: {
            "content-type": "application/json",
            accept: "application/json, text/event-stream",
            ...upstreamHeaders,
            ...(upstreamSessionId ? { "mcp-session-id": upstreamSessionId } : {}),
        },
        body: JSON.stringify(message),
        signal: AbortSignal.timeout(timeoutMs),
    });
    const nextSession = response.headers.get("mcp-session-id");
    if (nextSession)
        upstreamSessionId = nextSession;
    if (!response.ok)
        throw new Error(`connector service returned HTTP ${response.status}`);
    return parseUpstream(await readBounded(response), message.id);
}
const BAD_AUTH_CONFIG_ID = "OpenMausBot showed no card: auth_config_id must be a Composio auth config id (ac_ and then letters "
    + "or digits), copied from Auth Configs in the person's Composio project. Leave it out to use their newest enabled config.";
/** Composio's own error names `auth_config_override`, so either spelling is read: on a toolkit entry, or at the top level
 * as one id for a single toolkit or a { toolkit: id } map. */
function requestedAuthConfig(row) {
    return row.auth_config_id ?? row.auth_config_override;
}
function topLevelAuthConfig(args, slug, toolkitCount) {
    const value = requestedAuthConfig(args);
    if (value && typeof value === "object" && !Array.isArray(value)) {
        return Object.entries(value).find(([key]) => key.trim().toLowerCase() === slug)?.[1];
    }
    // One id cannot say which of several toolkits it belongs to.
    return value !== undefined && toolkitCount !== 1 ? null : value;
}
function connectorAdds(args) {
    if (!args || typeof args !== "object" || Array.isArray(args))
        return { requests: [], badAuthConfig: false };
    const toolkits = args.toolkits;
    if (!Array.isArray(toolkits))
        return { requests: [], badAuthConfig: false };
    const seen = new Set();
    const requests = [];
    for (const item of toolkits) {
        if (typeof item === "string") {
            const slug = item.trim().toLowerCase();
            const key = JSON.stringify([slug, ""]);
            if (!seen.has(key)) {
                seen.add(key);
                requests.push({ slug });
            }
            continue;
        }
        if (!item || typeof item !== "object" || Array.isArray(item))
            continue;
        const row = item;
        const action = String(row.action ?? "add").toLowerCase();
        if (!["add", "connect", "initiate"].includes(action))
            continue;
        const slug = typeof row.toolkit === "string" ? row.toolkit : row.name;
        if (typeof slug !== "string")
            continue;
        const normalized = slug.trim().toLowerCase();
        const alias = (typeof row.alias === "string" ? row.alias : typeof row.account === "string" ? row.account : "").trim();
        const key = JSON.stringify([normalized, alias.toLowerCase()]);
        if (seen.has(key))
            continue;
        seen.add(key);
        const authConfig = requestedAuthConfig(row);
        requests.push({ slug: normalized, ...(alias ? { alias } : {}), ...(authConfig !== undefined ? { authConfig } : {}) });
    }
    let badAuthConfig = false;
    const checked = requests.map(({ authConfig, ...request }) => {
        const value = authConfig ?? topLevelAuthConfig(args, request.slug, requests.length);
        if (value === undefined)
            return request;
        if (typeof value !== "string" || !AUTH_CONFIG_ID.test(value.trim())) {
            badAuthConfig = true;
            return request;
        }
        return { ...request, authConfigId: value.trim() };
    });
    return { requests: checked, badAuthConfig };
}
/** Resolves to the harness's line on which auth config each toolkit connects with, when it names one. */
async function showConnectorCards(items) {
    const response = await fetch(`${HARNESS}/api/internal/connectors/request`, {
        method: "POST",
        headers: { "content-type": "application/json", authorization: `Bearer ${TOKEN}` },
        body: JSON.stringify({ botId: BOT_ID, threadId: THREAD_ID, items, resumeKey: randomUUID() }),
        signal: AbortSignal.timeout(30_000),
    });
    const body = (await response.json().catch(() => ({})));
    if (!response.ok)
        throw new Error(String(body.error ?? `could not show connection card (HTTP ${response.status})`));
    return typeof body.authConfigNote === "string" && body.authConfigNote ? ` ${body.authConfigNote}` : "";
}
/** The upstream list with the app tools after it, unless it already has one by that name. */
function withAppTools(frame) {
    const result = frame.result;
    if (!APP_TOOLS.length || !result || !Array.isArray(result.tools))
        return frame;
    const listed = new Set(result.tools.map((tool) => tool?.name));
    const added = appToolEntries(APP_TOOLS, APP_TOOL_NAMES).filter((tool) => !listed.has(tool.name));
    return { ...frame, result: { ...result, tools: [...result.tools, ...added] } };
}
function rememberSchemas(frame) {
    const tools = frame.result?.tools;
    if (Array.isArray(tools)) {
        for (const tool of tools) {
            const { name, inputSchema } = (tool ?? {});
            if (typeof name === "string" && inputSchema !== undefined)
                SCHEMAS.set(name, inputSchema);
        }
    }
    return frame;
}
/** A call refused over its arguments says how to call again; one whose arguments were fitted says how they were read. */
function withArgumentNotes(name, response, changed) {
    const error = response.error;
    if (error && typeof error.message === "string" && ARGUMENT_REFUSAL.test(error.message)) {
        return textResult(response.id, `${error.message}\n\n${argumentRefusalNote(name, SCHEMAS.get(name), USABLE_APPS)}`, true);
    }
    if (annotateFailedCall(response, ARGUMENT_REFUSAL, (tools) => argumentRefusalNote(tools[0] ?? name, SCHEMAS.get(tools[0] ?? name), USABLE_APPS), [name]))
        return response;
    const result = response.result;
    if (changed.length && result && result.isError !== true && Array.isArray(result.content))
        result.content.push({ type: "text", text: fittedArgumentsNote(name, changed) });
    return response;
}
function fittedList(frame) {
    if ((!SCHEMA_PROFILE && TOOL_LIMIT === undefined) || !("result" in frame))
        return frame;
    const log = (line) => process.stderr.write(`connector-proxy: ${line}\n`);
    return { ...frame, result: capToolListResult(fitToolListResult(frame.result, SCHEMA_PROFILE, log), TOOL_LIMIT, log) };
}
async function handle(received) {
    let message = received;
    const id = message.id;
    const method = String(message.method ?? "");
    // OpenCode and other MCP clients mark a stdio server failed unless initialize returns capabilities and serverInfo.
    if (method === "notifications/initialized" || method === "initialized") {
        if (UPSTREAM)
            void relay(message).catch(() => { });
        return;
    }
    if (method === "initialize") {
        if (UPSTREAM) {
            try {
                // A stalled provider must never keep the local MCP client from mounting the connector tools.
                await relay(message, INITIALIZE_RELAY_TIMEOUT_MS);
            }
            catch {
            }
        }
        if (id !== undefined) {
            const params = (message.params ?? {});
            send(initializeResult(id, params.protocolVersion));
        }
        return;
    }
    let changed = [];
    if (method === "tools/call") {
        const given = (message.params ?? {});
        const name = String(given.name ?? "");
        const fitted = SCHEMAS.has(name) ? fitArguments(given.arguments, SCHEMAS.get(name)) : { args: given.arguments, changed: [] };
        changed = fitted.changed;
        if (changed.length)
            message = { ...message, params: { ...given, arguments: fitted.args } };
        const params = (message.params ?? {});
        const { requests, badAuthConfig } = /MANAGE_CONNECTIONS$/i.test(name)
            ? connectorAdds(params.arguments)
            : { requests: [], badAuthConfig: false };
        if (badAuthConfig) {
            send(textResult(id, BAD_AUTH_CONFIG_ID, true));
            return;
        }
        if (requests.length) {
            const authConfigNote = await showConnectorCards(requests);
            const labels = requests.map((r) => (r.alias ? `${r.slug} (${r.alias})` : r.slug)).join(", ");
            send(textResult(id, `OpenMausBot showed the user a secure connection card for ${labels}.${authConfigNote} End this turn now. The app will continue the task automatically after the connection finishes.`));
            return;
        }
        if (/WAIT_FOR_CONNECTIONS$/i.test(name)) {
            send(textResult(id, "OpenMausBot is handling connection completion and will continue the task automatically."));
            return;
        }
        const app = appToolCall(name, params.arguments);
        if (app) {
            const call = app.frame(id);
            const response = await relay(call);
            if (response && id !== undefined)
                send(appToolAnswer(app.slug, withSignedOutHint(call, response, SERVICE_SLUGS)));
            return;
        }
    }
    try {
        // The engine lists tools once per session, so one failed listing would leave the whole session without them.
        const response = method === "tools/list"
            ? await relay(message).catch(() => delay(TOOLS_LIST_RETRY_MS).then(() => relay(message)))
            : await relay(message);
        if (response && id !== undefined) {
            const name = String(message.params?.name ?? "");
            send(method === "tools/list" ? fittedList(rememberSchemas(withAppTools(withAuthConfigParameter(ALLOWED_TOOLS ? filterToolsListFrame(response, ALLOWED_TOOLS, SERVICE_SLUGS) : response))))
                : method === "tools/call" ? withArgumentNotes(name, withSignedOutHint(message, response, SERVICE_SLUGS), changed) : response);
        }
    }
    catch (error) {
        if (id === undefined)
            return;
        const messageText = error instanceof Error ? error.message : String(error);
        if (method === "tools/call")
            send(textResult(id, messageText, true));
        else
            send(jsonRpcError(id, messageText));
    }
}
const input = readline.createInterface({ input: process.stdin, terminal: false });
input.on("line", (line) => {
    const trimmed = line.trim();
    if (!trimmed)
        return;
    let message;
    try {
        message = JSON.parse(trimmed);
    }
    catch {
        return;
    }
    void handle(message).catch((error) => {
        if (message.id === undefined)
            return;
        const method = String(message.method ?? "");
        const messageText = error instanceof Error ? error.message : String(error);
        if (method === "tools/call")
            send(textResult(message.id, messageText, true));
        else
            send(jsonRpcError(message.id, messageText));
    });
});
input.on("close", () => process.exit(0));
