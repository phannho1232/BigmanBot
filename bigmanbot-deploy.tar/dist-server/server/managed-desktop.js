import { createHash } from "node:crypto";
import { existsSync, lstatSync, mkdirSync, renameSync } from "node:fs";
import { join } from "node:path";
import { z } from "zod";
const uuid = z.string().uuid();
const model = z.string().regex(/^[A-Za-z0-9][A-Za-z0-9._/:+-]{0,199}$/).refine(value => !value.includes("::"));
const connectionSchema = z.object({
    portalOrigin: z.string().max(2048), organizationId: uuid, organizationName: z.string().trim().min(1).max(100),
    email: z.string().email().max(320), deviceId: uuid, token: z.string().regex(/^omg_[A-Za-z0-9_-]{43}$/),
    expiresAt: z.number().finite().int().positive(),
    providers: z.array(z.object({ id: z.enum(["anthropic", "openai", "openrouter"]), configured: z.boolean(), models: z.array(model).max(500) }).strict()).max(3),
    suspended: z.literal("license-expired").optional(),
}).strict();
/** The saved enrollment's identity, never its token. */
const identitySchema = z.object({ portalOrigin: z.string().max(2048), organizationId: uuid, email: z.string().email().max(320), deviceId: uuid }).strict();
const PROVIDER_IDS = ["anthropic", "openai", "openrouter"];
const signature = (value) => createHash("sha256").update(JSON.stringify(value)).digest("hex");
const expiredMessage = "Company access has ended. Reconnect your organization or explicitly choose a personal model; personal billing will not be used automatically.";
export const LICENSE_EXPIRED_MESSAGE = "Your organization's OpenMaus Admin license has expired. Contact your admin.";
/** Only for messages from Electron's private utility-parent port: never renderer HTTP, never merged into saved AppConfig. */
export function parseManagedDesktopConnection(raw, now = Date.now()) {
    if (raw === null)
        return null;
    const parsed = connectionSchema.safeParse(raw);
    if (!parsed.success)
        throw new Error("Invalid Company connection from the desktop parent.");
    const value = parsed.data, url = new URL(value.portalOrigin);
    if (url.username || url.password || url.pathname !== "/" || url.search || url.hash ||
        (url.protocol !== "https:" && !(url.protocol === "http:" && ["127.0.0.1", "localhost", "[::1]"].includes(url.hostname)))) {
        throw new Error("Company connection must use an HTTPS origin or loopback fixture.");
    }
    if (value.expiresAt <= now)
        throw new Error("Company connection expired. Reconnect your organization.");
    if (new Set(value.providers.map(provider => provider.id)).size !== value.providers.length)
        throw new Error("Duplicate Company provider configuration.");
    return { ...value, portalOrigin: url.origin, email: value.email.toLowerCase(), providers: value.providers.map(provider => ({ ...provider, models: [...new Set(provider.models)] })).sort((a, b) => a.id.localeCompare(b.id)) };
}
export function companyInstanceId(connection, provider) {
    return `company.${signature([connection.portalOrigin, connection.organizationId, connection.email.toLowerCase()]).slice(0, 24)}.${provider}`;
}
export function legacyCompanyInstanceId(connection, provider) {
    return `company.${signature([connection.portalOrigin, connection.organizationId, connection.deviceId]).slice(0, 24)}.${provider}`;
}
const instanceSignature = (connection) => signature(connection && (({ expiresAt: _expiresAt, suspended: _suspended, ...identity }) => identity)(connection));
export function companyInstanceConfigs(connection, runtimeDirectory) {
    const entries = {};
    for (const provider of connection.providers) {
        if (!provider.configured || !provider.models.length)
            continue;
        const id = companyInstanceId(connection, provider.id), base = `${connection.portalOrigin}/api/desktop/gateway/${provider.id}`;
        const displayName = `Company · ${connection.organizationName} · ${provider.id === "anthropic" ? "Claude" : provider.id === "openai" ? "Codex" : "OpenRouter"}`;
        if (provider.id === "anthropic")
            entries[id] = {
                driver: "claudeAgent", displayName,
                config: { configDir: join(runtimeDirectory, id, "claude"), managed: true },
                environment: { ANTHROPIC_API_KEY: connection.token, ANTHROPIC_AUTH_TOKEN: connection.token, ANTHROPIC_BASE_URL: base, ANTHROPIC_MODEL: provider.models[0] },
            };
        if (provider.id === "openai")
            entries[id] = {
                driver: "codex", displayName, config: { managed: { url: `${base}/v1`, models: provider.models } },
                environment: { OPENMAUSBOT_COMPANY_API_KEY: connection.token, CODEX_HOME: join(runtimeDirectory, id, "codex") },
            };
        if (provider.id === "openrouter")
            entries[id] = {
                driver: "openai-compat", displayName, config: { url: `${base}/v1`, apiKeyEnv: "OPENMAUSBOT_COMPANY_API_KEY", model: provider.models[0], provider: "" },
                environment: { OPENMAUSBOT_COMPANY_API_KEY: connection.token },
            };
    }
    return entries;
}
/** Revocation fences wrappers synchronously, then stops only their instances. */
export class ManagedDesktopProviders {
    connection = null;
    currentSignature = signature(null);
    revision = 0;
    ids = new Set();
    tail = Promise.resolve();
    timer;
    now;
    options;
    constructor(options) { this.options = options; this.now = options.now ?? Date.now; }
    info(instanceId) {
        if (!this.ids.has(instanceId) || !this.connection || this.connection.expiresAt <= this.now())
            return;
        return { organizationId: this.connection.organizationId, organizationName: this.connection.organizationName };
    }
    /** So a personal instance that happens to be named company.* is never treated as managed. */
    known = new Set();
    owns(instanceId) { return this.known.has(instanceId); }
    enrolled() { return this.connection !== null; }
    apply(raw, force = false) {
        const connection = parseManagedDesktopConnection(raw, this.now()), nextSignature = instanceSignature(connection);
        if (!force && nextSignature === this.currentSignature) {
            const previous = this.connection;
            this.connection = connection;
            if (connection && previous && (connection.expiresAt !== previous.expiresAt || connection.suspended !== previous.suspended)) {
                clearTimeout(this.timer);
                this.scheduleExpiry(this.revision);
                this.options.onAvailability?.();
            }
            return this.tail;
        }
        this.currentSignature = nextSignature;
        this.connection = connection;
        const revision = ++this.revision;
        clearTimeout(this.timer);
        const replace = async () => {
            const previous = [...this.ids];
            await this.options.beforeReplace?.(previous);
            for (const id of previous)
                await this.options.registry.dispose(id);
            this.ids.clear();
            if (revision !== this.revision || !connection || connection.expiresAt <= this.now()) {
                this.options.afterReplace?.([]);
                return;
            }
            // Outside portable workspace backups; scoped ids keep a new enrollment from inheriting another account's sessions.
            const directory = this.ensureDirectory(["providers", "company"]);
            await this.migrateLegacyIds(connection);
            const configs = companyInstanceConfigs(connection, directory);
            for (const [id, entry] of Object.entries(configs)) {
                if (this.options.registry.entries().some(existing => existing.instanceId === id))
                    throw new Error("Company instance conflicts with an existing account.");
                if (entry.driver === "claudeAgent" || entry.driver === "codex") {
                    this.ensureDirectory(["providers", "company", id, entry.driver === "claudeAgent" ? "claude" : "codex"]);
                }
                this.ids.add(id);
                this.known.add(id);
            }
            const active = () => revision === this.revision && Boolean(this.connection && this.connection.expiresAt > this.now() && !this.connection.suspended);
            const unavailable = () => this.connection?.suspended === "license-expired" ? LICENSE_EXPIRED_MESSAGE : expiredMessage;
            await this.options.registry.load(configs, instance => {
                const provider = connection.providers.find(provider => companyInstanceId(connection, provider.id) === instance.instanceId);
                const models = { default: provider.models[0], options: provider.models.map(id => ({ id, label: `${id} (Company)` })) };
                return {
                    ...instance, models,
                    refreshModels: async () => { },
                    startAuthentication: undefined, getAuthentication: undefined, completeAuthentication: undefined, cancelAuthentication: undefined, signOut: undefined,
                    snapshot: async () => {
                        if (!active())
                            return { state: "unavailable", reason: unavailable() };
                        const snapshot = await instance.snapshot();
                        if (!active())
                            return { state: "unavailable", reason: unavailable() };
                        return { ...snapshot, authenticated: snapshot.state === "available", billing: "metered", account: { email: connection.email, organization: connection.organizationName, method: "api-key" } };
                    },
                    adapter: {
                        ...instance.adapter,
                        sendTurn: async (input) => {
                            if (!active())
                                throw new Error(unavailable());
                            if (!input.model || !provider.models.includes(input.model))
                                throw new Error("This model is not enabled by your Company administrator.");
                            return instance.adapter.sendTurn(input);
                        },
                    },
                };
            });
            if (revision === this.revision) {
                this.options.afterReplace?.([...this.ids]);
                this.scheduleExpiry(revision);
            }
        };
        this.tail = this.tail.catch(() => { }).then(replace).catch(async (error) => {
            // Never invalidate a newer queued grant.
            if (revision === this.revision) {
                this.revision++;
                this.connection = null;
                this.currentSignature = null;
                clearTimeout(this.timer);
            }
            await Promise.allSettled([...this.ids].map(id => this.options.registry.dispose(id)));
            this.ids.clear();
            this.options.afterReplace?.([]);
            throw error;
        });
        return this.tail;
    }
    ensureDirectory(parts) {
        // Only the configured root may be an operator-chosen alias; no owned descendant may redirect into personal homes.
        mkdirSync(this.options.dataDirectory, { recursive: true, mode: 0o700 });
        let directory = this.options.dataDirectory;
        for (const part of parts) {
            directory = join(directory, part);
            try {
                mkdirSync(directory, { mode: 0o700 });
            }
            catch (error) {
                if (error.code !== "EEXIST")
                    throw error;
            }
            const stat = lstatSync(directory);
            if (!stat.isDirectory() || stat.isSymbolicLink())
                throw new Error("Company native storage must be an owned workspace directory.");
        }
        return directory;
    }
    scheduleExpiry(revision) {
        const expiresAt = this.connection?.expiresAt;
        if (expiresAt === undefined)
            return;
        this.timer = setTimeout(() => {
            if (revision !== this.revision)
                return;
            if ((this.connection?.expiresAt ?? 0) > this.now())
                this.scheduleExpiry(revision);
            else
                void this.apply(null).catch(() => { });
        }, Math.min(2_147_483_647, Math.max(1, expiresAt - this.now())));
        this.timer.unref?.();
    }
    async migrateLegacyIds(identity) {
        try {
            const directory = this.ensureDirectory(["providers", "company"]);
            const aliases = PROVIDER_IDS.map(provider => ({ from: legacyCompanyInstanceId(identity, provider), to: companyInstanceId(identity, provider) }));
            for (const { from, to } of aliases) {
                const legacy = join(directory, from), stable = join(directory, to);
                if (!existsSync(legacy) || existsSync(stable))
                    continue;
                const stat = lstatSync(legacy);
                if (stat.isDirectory() && !stat.isSymbolicLink())
                    renameSync(legacy, stable);
            }
            await this.options.migrate?.(aliases);
        }
        catch (error) {
            console.warn(`[company] could not move saved Company model references to their stable ids: ${error instanceof Error ? error.message : String(error)}`);
        }
    }
    async migrateIdentity(raw) {
        const parsed = identitySchema.parse(raw), url = new URL(parsed.portalOrigin);
        if (url.origin !== parsed.portalOrigin || (url.protocol !== "https:" && !(url.protocol === "http:" && ["127.0.0.1", "localhost", "[::1]"].includes(url.hostname)))) {
            throw new Error("Company identity must use an HTTPS origin or loopback fixture.");
        }
        const identity = { ...parsed, email: parsed.email.toLowerCase() };
        const migration = this.tail.catch(() => { }).then(() => this.migrateLegacyIds(identity));
        this.tail = migration;
        return migration;
    }
    async close() {
        await this.apply(null, true);
    }
}
