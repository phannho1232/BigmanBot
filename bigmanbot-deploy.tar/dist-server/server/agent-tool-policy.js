/** The reviewed local reads of the built-in agents MCP. Names, prefixes or third-party annotations alone must never grant
 * read access; session recall keeps its own-bot scope. */
export const READ_ONLY_AGENT_TOOL_NAMES = new Set([
    "list_bots",
    "list_team_setup",
    "list_shared_computers",
    "list_rooms",
    "list_threads",
    "assignment_status",
    "session_search",
    "tool_result_read",
    "trigger_info",
    "list_waits",
    "skills_list",
    "list_unread_notifications",
]);
export const READ_ONLY_ANNOTATIONS = Object.freeze({
    readOnlyHint: true,
    destructiveHint: false,
    idempotentHint: true,
    openWorldHint: false,
});
export function isReadOnlyAgentTool(name) {
    return READ_ONLY_AGENT_TOOL_NAMES.has(name);
}
export function agentToolAnnotations(name) {
    return isReadOnlyAgentTool(name) ? READ_ONLY_ANNOTATIONS : undefined;
}
