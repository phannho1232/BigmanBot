// What this server remembers about the computers lent to it, so the person and their bots can tell "lent but offline
// since Tuesday" from "never lent", across restarts: a name, its platform, what it lends, when it was last online and
// last used, and whether its owner stopped lending. Never a folder path, a credential or anything a job carried.
import { existsSync, readFileSync } from "node:fs";
import { z } from "zod";
import { writeFileAtomic } from "./atomic.js";
export const LENT_PLATFORMS = ["darwin", "win32", "linux"];
const recordSchema = z.object({
    id: z.string().uuid(), person: z.string().min(1).max(200), name: z.string().min(1).max(120), platform: z.enum(LENT_PLATFORMS).nullable(),
    folders: z.number().int().min(0).max(20), terminal: z.boolean(), screen: z.boolean(), internet: z.boolean().optional(), chrome: z.boolean().optional(),
    lastSeenAt: z.number(), lastUsedAt: z.number().nullable(), stoppedAt: z.number().nullable(),
}).strict();
const fileSchema = z.object({ version: z.literal(1), computers: z.array(recordSchema).max(200) });
const KEEP_MS = 90 * 24 * 60 * 60_000;
const SEEN_WRITE_MS = 60_000;
const PER_PERSON = 10;
/** "PC" on Windows, "Mac" on macOS, else "computer": the word a bot uses for the person's device. */
export function deviceWord(platform) {
    return platform === "win32" ? "PC" : platform === "darwin" ? "Mac" : "computer";
}
export class LentComputers {
    file;
    now;
    computers = [];
    written = new Map();
    constructor(file, now = Date.now) {
        this.file = file;
        this.now = now;
        try {
            if (existsSync(file))
                this.computers = fileSchema.parse(JSON.parse(readFileSync(file, "utf8"))).computers;
        }
        catch {
            // A record that cannot be read only loses history; lending itself does not depend on it.
            console.warn("lending: the record of lent computers could not be read; starting a new one");
        }
    }
    save() {
        const cutoff = this.now() - KEEP_MS;
        this.computers = this.computers.filter((computer) => computer.lastSeenAt >= cutoff);
        try {
            writeFileAtomic(this.file, `${JSON.stringify({ version: 1, computers: this.computers })}\n`, { mode: 0o600 });
        }
        catch (error) {
            console.warn(`lending: could not save the record of lent computers: ${error instanceof Error ? error.message : String(error)}`);
        }
    }
    find(person, id) {
        return this.computers.find((computer) => computer.person === person && computer.id === id);
    }
    /** A computer that registered, now lending these scopes. Each new grant has a new id, so a computer is known by its
     * name: lending again from the same computer updates its one record. A person's newest computers are kept. */
    connected(person, input) {
        const at = this.now();
        const same = (computer) => computer.person === person && (computer.id === input.id || computer.name === input.name);
        const previous = this.computers.find(same);
        const next = { id: input.id, person, name: input.name, platform: input.platform ?? previous?.platform ?? null, folders: input.folders,
            terminal: input.terminal, screen: input.screen, internet: input.internet === true, chrome: input.chrome === true, lastSeenAt: at, lastUsedAt: previous?.lastUsedAt ?? null, stoppedAt: null };
        const others = this.computers.filter((computer) => !same(computer));
        const mine = [next, ...others.filter((computer) => computer.person === person)].slice(0, PER_PERSON);
        this.computers = [...mine, ...others.filter((computer) => computer.person !== person)];
        this.written.set(`${person}\n${input.id}`, at);
        this.save();
    }
    /** It polled: written at most once a minute, so "last online" is never more than a minute behind. */
    seen(person, id) {
        const computer = this.find(person, id);
        if (!computer)
            return;
        const at = this.now();
        computer.lastSeenAt = at;
        const key = `${person}\n${id}`;
        if (at - (this.written.get(key) ?? 0) < SEEN_WRITE_MS)
            return;
        this.written.set(key, at);
        this.save();
    }
    used(person, id) {
        const computer = this.find(person, id);
        if (!computer)
            return;
        computer.lastUsedAt = computer.lastSeenAt = this.now();
        this.save();
    }
    /** Its owner turned lending off on that computer: it is no longer lent, not merely offline. */
    stopped(person, id) {
        const computer = this.find(person, id);
        if (!computer)
            return;
        computer.stoppedAt = computer.lastSeenAt = this.now();
        this.save();
    }
    list(person) {
        if (!person)
            return [];
        return this.computers.filter((computer) => computer.person === person).sort((a, b) => b.lastSeenAt - a.lastSeenAt);
    }
}
/** What makes a lent computer lend its apps and screen: OpenMausBot on it lends them by itself once computer control works there. */
export const lendScreenSteps = (device) => device === "Mac"
    ? "OpenMausBot on that Mac lends them by itself once macOS allows it Accessibility and Screen Recording: tell the person in one sentence to allow both for OpenMausBot in System Settings → Privacy & Security on that Mac, and to update OpenMausBot there if it is an older version."
    : `OpenMausBot on that ${device} lends them by itself once its computer control works: tell the person in one sentence to check computer control in OpenMausBot on that ${device}, and to update OpenMausBot there if it is an older version.`;
const dateText = (at) => new Date(at).toISOString().slice(0, 16).replace("T", " ") + " UTC";
/**
 * What list_shared_computers adds for a bot when a computer it knows is not online: the computer by name and kind, since
 * when, and the one sentence to say. Nothing when every known computer is online.
 */
export function awayNotice(known, online, askTool = null) {
    const away = known.filter((computer) => !online.has(computer.id));
    if (!away.length || known.some((computer) => online.has(computer.id)))
        return {};
    const offline = away.slice(0, 3).map((computer) => ({ name: computer.name, device: deviceWord(computer.platform), lastOnline: dateText(computer.lastSeenAt), lent: computer.stoppedAt === null }));
    const latest = away[0];
    const device = deviceWord(latest.platform);
    const ask = askTool ? ` If the request needs it, call ${askTool}: it asks them with a one-tap Turn on, and you carry on once it's on. Don't explain the fix in chat.` : null;
    const say = latest.stoppedAt === null
        ? `Their ${device} ${latest.name} is shared with the Cloud but offline (last online ${dateText(latest.lastSeenAt)}): OpenMausBot on it is closed, or the ${device} is asleep or off.${ask ?? ` Ask them to open OpenMausBot on that ${device}; it reconnects by itself.`}`
        : `Their ${device} ${latest.name} no longer shares itself with the Cloud: OpenMausBot on it is paused, or signed out of MausBot Cloud.${ask ?? ` Ask them to choose Resume from OpenMausBot's icon in the ${device === "Mac" ? "menu bar" : "taskbar"} on that ${device}, or sign in there again.`}`;
    return { offline, say };
}
