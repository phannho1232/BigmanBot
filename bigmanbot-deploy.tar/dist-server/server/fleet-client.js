// One request over the fleet agent's Unix socket; the socket's permissions are the whole authorisation.
import { existsSync } from "node:fs";
import { request } from "node:http";
export function fleetSocketPath(env = process.env) {
    return env.OMB_FLEET_SOCKET?.trim() || "/run/openmausbot/fleet.sock";
}
export function fleetAvailable(socketPath = fleetSocketPath()) {
    return existsSync(socketPath);
}
export function fleetRequest(socketPath, method, path, body, timeoutMs = 15 * 60_000) {
    return new Promise((resolve, reject) => {
        const payload = body === undefined ? undefined : JSON.stringify(body);
        const req = request({ socketPath, method, path, headers: { "content-type": "application/json", ...(payload ? { "content-length": Buffer.byteLength(payload) } : {}) }, timeout: timeoutMs }, (res) => {
            let text = "";
            res.setEncoding("utf8");
            res.on("data", (chunk) => { if (text.length < 1_000_000)
                text += chunk; });
            res.on("end", () => {
                let parsed = null;
                try {
                    parsed = text ? JSON.parse(text) : null;
                }
                catch {
                    parsed = { error: "the fleet agent answered something that was not JSON" };
                }
                resolve({ status: res.statusCode ?? 502, body: parsed });
            });
        });
        req.on("timeout", () => { req.destroy(new Error("the fleet agent did not answer in time")); });
        req.on("error", (error) => {
            reject(new Error(error.code === "ENOENT" || error.code === "ECONNREFUSED"
                ? "no fleet agent on this server: run `openmausbot fleet init --domain … --operator <this user>` as root"
                : error.code === "EACCES"
                    ? "this workspace's user may not open the fleet socket: re-run `openmausbot fleet init` with --operator set to it"
                    : `fleet agent: ${error.message}`));
        });
        if (payload)
            req.write(payload);
        req.end();
    });
}
